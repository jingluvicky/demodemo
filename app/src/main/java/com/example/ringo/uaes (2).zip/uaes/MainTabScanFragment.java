package com.example.ringo.uaes;

/**
 * Created by ringo on 2017/6/25.
 */

import android.app.ListFragment;
import android.app.Fragment;
import android.app.FragmentManager;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.AdvertiseCallback;
import android.bluetooth.le.AdvertiseData;
import android.bluetooth.le.AdvertiseSettings;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.ComponentName;
import android.content.ServiceConnection;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.ParcelUuid;
import android.service.autofill.Dataset;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.Toast;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.annotation.SuppressLint;
import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.content.Context;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.util.Log;
import java.util.ArrayList;
import android.Manifest;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.app.Dialog;

import org.w3c.dom.Text;

import java.util.List;
import java.util.UUID;
import java.util.Map;
import java.util.HashMap;

import static android.bluetooth.le.ScanSettings.SCAN_MODE_LOW_LATENCY;


//This is the Ble tab, used to scan and find BLE devices during developing period
public class MainTabScanFragment extends Fragment  implements HandleNotify{
    private static final String TAG = "MainTabScanFragment";
    //Bluetooth
    private BluetoothManager mbluetoothManager;
    private BluetoothAdapter mbluetoothAdapter;
    private BluetoothLeScanner mbluetoothlescanner;
    private BluetoothDevice mdevice;
    private BluetoothGatt mbluetoothgatt;
    private BluetoothGattService mbluetoothgattservice;
    private BluetoothGattCharacteristic mbluetoothgattcharacteristic;
    private BluetoothGattCharacteristic mBluetoothGattCharacNotify;

    private final  String TARGET_DEVICE = "SMART PEPS DEMO";
    private final String service_uuid = "0000fff0-0000-1000-8000-00805f9b34fb";
    private final String charac_uuid =  "0000fff4-0000-1000-8000-00805f9b34fb";
    private final String WRITE_UUID =  "0000fff3-0000-1000-8000-00805f9b34fb";

    private final static UUID config_uuid =  UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");

    private Switch switch_connect;
    // Thread
    Handler periodShow=new Handler();
    Handler handlerWrite=new Handler();
    Thread writeThread,zoneRecognizeThread, motionRecognizeThread;
    PredictionTF_zone preTF_zone;
    PredictionTF_motion preTF_motion;

    // Variables

    public volatile boolean exit = false;
    public volatile boolean toConnect=true, isScan=false,isConnect=false;

    public static byte[] dataReceived=new byte[13];

    //
    public static Node[] Nodes = new Node[12];
    public KalmanFilter_A[] Kalman = new KalmanFilter_A[11];
    public KalmanFilter Kalman_main = new KalmanFilter();
    public static int curMotion=255,curZone=255,curLeftRight=255;
    public static float[] curMotionOutput,curZoneOutput;
    public int CMDCounter;
    public int CMDValue;
    public int []zonebuffer=new int[5],motionbuffer=new int[5];
    public static float distanceValue;
    private int MainRSSI;

    //Sensor values
    public static float[] linearAccValue,gravityValue,gyroValue;

    Runnable runnable=new Runnable() {
        @Override
        public void run() {
            TextView txt_RSSI=(TextView)getActivity().findViewById(R.id.txt_RSSI);
            for (int i=0;i<=10;i++){
                if (Nodes[i]==null)Nodes[i]=new Node();
            }
           txt_RSSI.setText("M :  "+(int)Nodes[0].RSSI_filtered+"\n"+
                    "A1:  "+(int)Nodes[1].RSSI_filtered+"\n"+
                    "A2:  "+(int)Nodes[2].RSSI_filtered+"\n"+
                    "A3:  "+(int)Nodes[3].RSSI_filtered+"\n"+
                    "A4:  "+(int)Nodes[4].RSSI_filtered+"\n"+
                    "A5:  "+(int)Nodes[5].RSSI_filtered+"\n"+
                    "A6:  "+(int)Nodes[6].RSSI_filtered+"\n"+
                   "A7:  "+(int)Nodes[7].RSSI_filtered+"\n"+
                   "A8:  "+(int)Nodes[8].RSSI_filtered+"\n"+
                   "A9:  "+(int)Nodes[9].RSSI_filtered+"\n"
           );

            int motionAverage=(int)(motionbuffer[0]+motionbuffer[1]+motionbuffer[2]+motionbuffer[3]+motionbuffer[4])/5;

            TextView txt_curZone = getActivity().findViewById(R.id.txt_curZone);
            if (curZoneOutput!=null) {
                txt_curZone.setText("Current Zone:  " + curZone );
            }
            ImageView img_scan=getActivity().findViewById(R.id.img_scan);
            if (isScan){
                img_scan.setImageResource(R.mipmap.greenicon);
            }else{
                img_scan.setImageResource(R.mipmap.redicon2);
            }
            ImageView img_connect=getActivity().findViewById(R.id.img_connect);
            if(isConnect){
                img_connect.setImageResource(R.mipmap.greenicon);
            }else{
                img_connect.setImageResource(R.mipmap.redicon2);
            }



            periodShow.postDelayed(this,100);
        }
    };
   public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        View view = inflater.inflate(R.layout.fragment_ble, container, false);

       periodShow.postDelayed(runnable,300);
        return view;
    }

    public void onActivityCreated(Bundle savedInstanceState){

       super.onActivityCreated(savedInstanceState);

        InitBluetoothService();
        preTF_zone=new PredictionTF_zone(this.getContext().getAssets());
        preTF_motion=new PredictionTF_motion(this.getContext().getAssets());

        //motionRecognizeThread.start();

        //zoneRecognizeThread.start();
        switch_connect=getActivity().findViewById(R.id.Switch_connect);
        switch_connect.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (SPUtils.getBoolean("BLE_ENABLE_SCAN")){
                    if (isChecked){

                        exit=false;
                        mbluetoothlescanner = mbluetoothAdapter.getBluetoothLeScanner();
                        Log.d(TAG, "onCreate: start scanner");
                        mbluetoothlescanner.startScan(scanCallback);
                        isScan=true;
                        toConnect=true;
                        motionRecognizeThread=new Thread(runnableMotionRecognize);
                        zoneRecognizeThread = new Thread(runnableZoneRecognize);
                        motionRecognizeThread.start();
                        zoneRecognizeThread.start();

                    }else{
                        exit=true;
                        toConnect=false;
                        if (mbluetoothgatt!=null){
                            mbluetoothgatt.disconnect();
                            mbluetoothgatt.close();
                            isConnect=false;
                            curMotion=255;curZone=255;curLeftRight=255;
                        }

                        Nodes=new Node[12];
                        Log.d(TAG,"Disconnect");
                        mbluetoothAdapter.getBluetoothLeAdvertiser().stopAdvertising(mAdvertiseCallback);
                        Log.d(TAG,"Stop advertising");
                        //if (writeThread.getState()==Thread.State.RUNNABLE)
                        mbluetoothlescanner.stopScan(scanCallback);
                        isScan=false;
                        handlerWrite.removeCallbacks(runnableWriteCharac);
                    }
                }else{
                    Toast.makeText(getActivity(), "You are not authorized!", Toast.LENGTH_SHORT).show();

                }

                            }
        });

    }

    private void InitBluetoothService(){
        mbluetoothManager = (BluetoothManager) getActivity().getSystemService(Context.BLUETOOTH_SERVICE);
        mbluetoothAdapter = mbluetoothManager.getAdapter();
        if (!mbluetoothAdapter.isEnabled())
        {
            startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE),0);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Log.d(TAG, "onCreate: Request permission");

        }
    }

    private ScanCallback scanCallback = new ScanCallback() {

        @Override
        public void onScanResult(int callbackType, ScanResult result) {
            super.onScanResult(callbackType, result);
            BluetoothDevice device = result.getDevice();
            Log.d(TAG, "onScanResult: "+device.getName() +":"+ device.getAddress());
            if(device.getName()!= null && device.getName().equals(TARGET_DEVICE))
            {
                Log.d(TAG, "run: stop scanner");

                Log.d(TAG, "onScanResult: device scan success,ready to connect");
                mdevice = device;
                mbluetoothgatt = mdevice.connectGatt(getContext(), false, new BluetoothGattCallback() {

                    @Override
                    public void onServicesDiscovered(BluetoothGatt gatt, int status) {
                        super.onServicesDiscovered(gatt, status);
                        Log.d(TAG, "onServicesDiscovered: 发现服务");
                        mbluetoothgattservice = mbluetoothgatt.getService(UUID.fromString(service_uuid));
                        Log.d(TAG, "onServicesDiscovered: " + mbluetoothgattservice.getUuid().toString());
                        mbluetoothgattcharacteristic = mbluetoothgattservice.getCharacteristic(UUID.fromString(WRITE_UUID));
                        mBluetoothGattCharacNotify=mbluetoothgattservice.getCharacteristic(UUID.fromString(charac_uuid));
                        if(mBluetoothGattCharacNotify != null)
                        {
                            setCharacteristicNotification(mBluetoothGattCharacNotify, true);
                            //                    boolean isEnableNotification =  mbluetoothgatt.setCharacteristicNotification(mbluetoothgattcharacteristic, true);
                            //                   if(isEnableNotification)
                            {
                                Log.d(TAG, "onEnableNotification: 使能成功"+mBluetoothGattCharacNotify.getUuid().toString());
                            }
                        }else
                        {
                            Log.d(TAG, "onServicesDiscovered: 发现服务失败");
                        }
                        if(mbluetoothgattcharacteristic!=null) {
                            writeThread = new Thread(runnableWriteCharac);
                            writeThread.start();

                            //handlerWrite.postDelayed(runnableWriteCharac,50);

                        }

                    }

                    @Override
                    public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
                        super.onCharacteristicChanged(gatt, characteristic);
                        Log.d(TAG, "onCharacteristicChanged: "+ characteristic.getStringValue(0));
                        dataReceived=characteristic.getValue();
                    }

                    @Override
                    public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
                        super.onConnectionStateChange(gatt, status, newState);
                        if(newState == BluetoothGatt.STATE_CONNECTED)
                        {
                            isConnect=true;
//                            mbluetoothgatt = gatt;
                            Log.d(TAG, "onConnectionStateChange: Connect");
                        }
                        gatt.discoverServices();
                        if(newState == BluetoothGatt.STATE_DISCONNECTED)
                        {
                            isConnect=false;
                            Nodes=new Node[12];
                            mbluetoothlescanner.startScan(scanCallback);
                            isScan=true;
                            Log.d(TAG, "onConnectionStateChange: Disconnect");
                        }

                    }
                    public void onReadRemoteRssi(BluetoothGatt gatt, int rssi, int status) {
                        super.onReadRemoteRssi(gatt, rssi, status);
                        MainRSSI=rssi;
                    }

                });
                if (mbluetoothgatt.connect()){

                    mbluetoothAdapter.getBluetoothLeAdvertiser().startAdvertising(createAdvSettings(false, 0),createAdvertiseData(), mAdvertiseCallback);
                    mbluetoothlescanner.stopScan(scanCallback);
                    isScan=false;

                }
            }
        }


    };

    public void setCharacteristicNotification(BluetoothGattCharacteristic characteristic,
                                              boolean enabled) {
        if (mbluetoothAdapter == null || mbluetoothgatt == null) {
            Log.w(TAG, "BluetoothAdapter not initialized");
            return;
        }
        boolean isEnableNotification =  mbluetoothgatt.setCharacteristicNotification(characteristic, enabled);
        if(isEnableNotification) {
            BluetoothGattDescriptor descriptor = characteristic.getDescriptor(config_uuid);
            descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
            mbluetoothgatt.writeDescriptor(descriptor);


        }
    }

    public AdvertiseSettings createAdvSettings(boolean connectAble, int timeoutMillis) {
        AdvertiseSettings.Builder builder = new AdvertiseSettings.Builder();
        builder.setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY);
        builder.setConnectable(connectAble);
        builder.setTimeout(timeoutMillis);
        builder.setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_HIGH);
        AdvertiseSettings mAdvertiseSettings = builder.build();
        if (mAdvertiseSettings == null) {
            Toast.makeText(getActivity(), "mAdvertiseSettings == null", Toast.LENGTH_LONG).show();
            Log.e(TAG, "mAdvertiseSettings == null");
        }
        return mAdvertiseSettings;
    }

    public AdvertiseData createAdvertiseData() {
        AdvertiseData.Builder mDataBuilder = new AdvertiseData.Builder();
        mDataBuilder.setIncludeDeviceName(true); //广播名称也需要字节长度
        mDataBuilder.setIncludeTxPowerLevel(true);
        mDataBuilder.addServiceData(ParcelUuid.fromString("0000fff0-0000-1000-8000-00805f9b34fb"),new byte[]{1,2});
        AdvertiseData mAdvertiseData = mDataBuilder.build();
        if (mAdvertiseData == null) {
            //	Toast.makeText(Main4Activity.this, "mAdvertiseSettings == null", Toast.LENGTH_LONG).show();
            Log.e(TAG, "mAdvertiseSettings == null");
        }
        return mAdvertiseData;
    }

    private AdvertiseCallback mAdvertiseCallback = new AdvertiseCallback() {
        @Override
        public void onStartSuccess(AdvertiseSettings settingsInEffect) {
            super.onStartSuccess(settingsInEffect);
            if (settingsInEffect != null) {
                Log.d(TAG, "onStartSuccess TxPowerLv=" + settingsInEffect.getTxPowerLevel() + " mode=" + settingsInEffect.getMode()
                        + " timeout=" + settingsInEffect.getTimeout());
            } else {
                Log.e(TAG, "onStartSuccess, settingInEffect is null");
            }
            Log.e(TAG, "onStartSuccess settingsInEffect" + settingsInEffect);

        }

        @Override
        public void onStartFailure(int errorCode) {
            super.onStartFailure(errorCode);
            Log.e(TAG, "onStartFailure errorCode" + errorCode);

            if (errorCode == ADVERTISE_FAILED_DATA_TOO_LARGE) {
                //	Toast.makeText(Main4Activity.this, "R.string.advertise_failed_data_too_large", Toast.LENGTH_LONG).show();
                Log.e(TAG, "Failed to start advertising as the advertise data to be broadcasted is larger than 31 bytes.");
            } else if (errorCode == ADVERTISE_FAILED_TOO_MANY_ADVERTISERS) {
                //Toast.makeText(Main4Activity.this, "R.string.advertise_failed_too_many_advertises", Toast.LENGTH_LONG).show();
                Log.e(TAG, "Failed to start advertising because no advertising instance is available.");
            } else if (errorCode == ADVERTISE_FAILED_ALREADY_STARTED) {
                //	Toast.makeText(Main4Activity.this, "R.string.advertise_failed_already_started", Toast.LENGTH_LONG).show();
                Log.e(TAG, "Failed to start advertising as the advertising is already started");
            } else if (errorCode == ADVERTISE_FAILED_INTERNAL_ERROR) {
                //Toast.makeText(Main4Activity.this, "R.string.advertise_failed_internal_error", Toast.LENGTH_LONG).show();
                Log.e(TAG, "Operation failed due to an internal error");
            } else if (errorCode == ADVERTISE_FAILED_FEATURE_UNSUPPORTED) {
                //	Toast.makeText(Main4Activity.this, "R.string.advertise_failed_feature_unsupported", Toast.LENGTH_LONG).show();
                Log.e(TAG, "This feature is not supported on this platform");
            }
        }
    };

    private Runnable runnableZoneRecognize=new Runnable() {
        public void run() {
            while(toConnect) {
                preTF_zone.Storage(Nodes);
                float[] outputs = preTF_zone.getPredict();

                float aa = -10;
                int aaa = 0;
                for (int i = 0; i < 4; i++) {
                    if (outputs[i] > aa) {
                        aa = outputs[i];
                        aaa = i;
                    }
                }
                if (aaa==0)aaa=4;
                if ( outputs[1]>8||outputs[2]>4||outputs[3]>4||outputs[0]>4){

                    curZone=aaa;
                }
                for(int i=7;i<=9;i++){
                    if (Nodes[i]==null){
                        Nodes[i]=new Node();
                        Nodes[i].RSSI_filtered=100;
                    }
                }
                if (Nodes[0]==null){
                    Nodes[0]=new Node();
                    Nodes[0].RSSI_filtered=100;
                }
                double max_inside=0;
                int max_inside_node=0;
                for (int i = 1; i <= 9; i++) {
                    if (Nodes[i]==null)Nodes[i]=new Node();
                }
                for (int i=7;i<=8;i++){
                    if (Nodes[i].RSSI_filtered>max_inside){
                        max_inside_node=i;
                        max_inside=Nodes[i].RSSI_filtered;
                    }
                }

                double min_outside=100;
                int max_outside_node=0;

                for (int i=1;i<=6;i++) {
                    if (Nodes[i].RSSI_filtered < min_outside) {
                        max_outside_node = i;
                        min_outside = Nodes[i].RSSI_filtered;
                    }
                }


                    if (
                        (Nodes[0].RSSI_filtered<=48 ||
                                (Nodes[0].RSSI_filtered>48 &&(Nodes[7].RSSI_filtered<=56 ||
                        Nodes[8].RSSI_filtered<=56||
                        Nodes[9].RSSI_filtered<=56))||
                                (max_inside<min_outside && distanceValue==0))
                    ){
                        curZone=0;
                }

               // Log.d("distance",distanceValue+" ");
                curZoneOutput=outputs;
                for (int i=0;i<4;i++){
                    zonebuffer[i]=zonebuffer[i+1];

                }
                zonebuffer[4]=curZone;
                //TextView txt_curZone = getActivity().findViewById(R.id.txt_curZone);
                //txt_curZone.setText("Current Zone:  " + aaa + "  \n" + outputs[0] + "  " + outputs[1] + " " + outputs[2]);
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
                //zonenumber = aaa + 1;
                //Log.d("TF_zone", MainRSSI_filtered + " " + AssistRSSI_1_filtered + "  " + AssistRSSI_2_filtered + "  " + aaa + "  " + outputs[0] + " " + outputs[1] + " " + outputs[2]);
            }

    };

    private Runnable runnableMotionRecognize=new Runnable() {
        public void run() {
            int counter_motion=0;
            while(toConnect) {

                if (gyroValue==null)gyroValue=new float[3];
                if (gravityValue==null)gravityValue=new float[3];
                if (linearAccValue==null)linearAccValue=new float[3];

                preTF_motion.Storage(gyroValue,linearAccValue,gravityValue);
                if (counter_motion==5) {
                    float[] outputs = preTF_motion.getPredict();

                    float aa = -10;
                    int aaa = 0;
                    for (int i = 0; i < 3; i++) {
                        if (outputs[i] > aa) {
                            aa = outputs[i];
                            aaa = i;
                        }
                    }
                    aaa = aaa + 1;
                    //Log.d("curMotion",aaa+" "+outputs[0]+" "+outputs[1]+" "+outputs[2]  );
                    if (aaa==2 && outputs[1]>3){
                        curMotion=aaa;
                    }else if(aaa!=2 ){
                        curMotion=aaa;
                    }
                        curMotionOutput=outputs;
                    for (int i=0;i<4;i++){
                        motionbuffer[i]=motionbuffer[i+1];

                    }
                    motionbuffer[4]=curZone;

                }
                if (counter_motion>5){
                    counter_motion=0;
                }else{
                    counter_motion++;
                }
                try {
                    Thread.sleep(20);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            //zonenumber = aaa + 1;
            //Log.d("TF_zone", MainRSSI_filtered + " " + AssistRSSI_1_filtered + "  " + AssistRSSI_2_filtered + "  " + aaa + "  " + outputs[0] + " " + outputs[1] + " " + outputs[2]);
        }

    };

    private Runnable runnableWriteCharac= new Runnable() {
        @Override
        public void run() {
            while(!exit){
                System.out.println("handler-->" + Thread.currentThread().getId());
                System.out.println("handler-->" + Thread.currentThread().getName());

                //change to 13 byte for multinode test cmd, main_rssi, assist_rssi1-8, assit_validity(9)
                byte[] atemp = new byte[]{0, 0, 0, 0, 0,
                        0, 0, 0, 0, 0,
                        0,0,0,0,0};

                readNotify();
                if (mbluetoothgatt.readRemoteRssi()) {
                    if (Nodes[0]==null) Nodes[0]=new Node();
                    Nodes[0].RSSI = Math.abs(MainRSSI);
                    Nodes[0].RSSI_filtered = Kalman_main.FilteredRSSI(Nodes[0].RSSI);
                }

                //refresh RSSI succeed11

                for (int i = 1; i <= 9; i++) {
                    if (Nodes[i]==null)Nodes[i]=new Node();
                }

               // zoneRecogniceThread = new Thread(runnableZoneRecognize);
               // zoneRecogniceThread.start();
                Integer[] I=new Integer[15];
                int temp;
                if(CMDCounter>0){
                    temp=(CMDValue);
                    CMDCounter--;}
                else{
                    CMDValue=0;
                    temp=0;
                }


                //Byte 0 in app => 4A3 byte 1
                I[0]=temp;
                //Byte 1 in app => 4A3 byte 2
                I[1] = curZone;// 4A3-1
                //Byte 2 in app => 4A3 byte 4
                I[2] =curLeftRight;
                //Byte 3 in app => 4A3 byte 6
                I[3] = 0;
                //Byte 4 in app => 4A3 byte 8
                if (curMotion==2)
                I[4] = 1;//4A3-8
                else I[4]=0;
                //Byte 5 in app => 4A8 byte 1
                I[5] = (int)Nodes[0].RSSI_filtered;//4A8-1
                //Byte 6 in app => 4A8 byte 2
                I[6]=(int)Nodes[1].RSSI_filtered;//4A8-2
                //Byte 7 in app => 4A8 byte 3
                I[7] = (int)Nodes[2].RSSI_filtered;//4A8-3
                //Byte 8 in app => 4A8 byte 4
                I[8]=(int)Nodes[3].RSSI_filtered;//4A8-4

                //Byte 9 in app => 4A8 byte 5
                I[9]=(int)Nodes[4].RSSI_filtered;//4A8-5

                I[10]=(int)Nodes[5].RSSI_filtered;

                I[11]=(int)Nodes[6].RSSI_filtered;
                I[12]=(int)Nodes[7].RSSI_filtered;
                I[13]=(int)Nodes[8].RSSI_filtered;
                I[14]=(int)Nodes[9].RSSI_filtered;
                //Log.d(TAG,"write to service");
                //readNotify();


                for (int i=0;i<=14;i++){
                    atemp[i]=I[i].byteValue();
                }


                mbluetoothgattcharacteristic.setValue(atemp);
                mbluetoothgatt.writeCharacteristic(mbluetoothgattcharacteristic);
               try{
                   Thread.sleep(50);
               }catch(InterruptedException e){
                   e.printStackTrace();
               }
               // handlerWrite.postDelayed(this,50);
                // 50是延时时长
            }

        }
    };
    //Log.d(TAG, "run: ******************" + (mBluetoothLeService == null));
    private void readNotify(){

        //Byte 2-11 current assist BLE RSSI
        for (int i=1;i<=10;i++){
            if (Nodes[i]==null)Nodes[i]=new Node();
            Nodes[i].RSSI=-dataReceived[i];
            if (Kalman[i]==null) Kalman[i]=new KalmanFilter_A();
            Nodes[i].RSSI_filtered = Kalman[i].FilteredRSSI((double) Nodes[i].RSSI, Nodes[i].Validaty);
            //Log.d("NodeRSSI",dataReceived[0]+" "+dataReceived[1]+" "+dataReceived[2]+" "+dataReceived[11]+" "+dataReceived[12]+" ");

        }

        //Byte 12 Validity assist RSSI 1-8
        byte validity_1=dataReceived[11];
        byte[] array = new byte[8];
        for (int i = 7; i >= 0; i--) {
            array[i] = (byte)(validity_1 & 1);
            validity_1 = (byte) (validity_1 >> 1);
            if (array[i]==1) Nodes[i+1].Validaty=true;else Nodes[i+1].Validaty=true;
        }

       /* Log.d("validate",dataReceived[11]+" ");
        for (int i=7;i>=0;i--){
            if (validity_1>=Math.pow(2,i)){
                Nodes[i+1].Validaty=true;
                //validity_1=validity_1-(int)Math.pow(2,i);

            }else{
                Nodes[i+1].Validaty=false;///////////////////////////****************************************************************

            }
        }
       */ //Byte 13 Validity Assist RSSI 9-10
        int validity_2=dataReceived[12];
        for (int i=1;i>=0;i--){
            if (validity_2>=Math.pow(2,i)){
                Nodes[i+9].Validaty=true;
                validity_2=validity_2-(int)Math.pow(2,i);
            }else{Nodes[i+9].Validaty=true;}/////////////*********************************************************************************888
        }

        if(Nodes[2].RSSI_filtered+Nodes[3].RSSI_filtered>Nodes[5].RSSI_filtered+Nodes[6].RSSI_filtered){
            curLeftRight=0;
        }else{
            curLeftRight=1;
        }

    }

    public void setCMDCounter(int value) {

        CMDCounter = 6; //Set the send times
        CMDValue = value; //Specify the control value
    }

    @Override
    public void onVehicleKeyReceived() {
        // 已经授权，需要打开扫描开关
        SPUtils.save("BLE_ENABLE_SCAN", true);


    }

    @Override
    public void onVehicleKeyCanceled() {
        // 取消授权，关闭扫描开关
        SPUtils.save("BLE_ENABLE_SCAN", false);
    }

    @Override
    public void onResume() {
        super.onResume();
        boolean isOwner = SPUtils.getBoolean("IS_OWNER");
        if (isOwner) {
            // 需要打开扫描开关
            SPUtils.save("BLE_ENABLE_SCAN", true);
        } else {
            // 需要关闭扫描开关
            SPUtils.save("BLE_ENABLE_SCAN", false);
        }
    }


}
//End of Fragment Class
