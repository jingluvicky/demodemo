package com.example.ringo.uaes;

import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Matrix;
import android.util.Log;

import org.tensorflow.contrib.android.TensorFlowInferenceInterface;


public class PredictionTF_motion {
    private static final String TAG = "PredictionTF";
    //设置模型输入/输出节点的数据维度

    private static final int WINDOW = 80;
    private static final int SENSORNUMBER=9;

    //模型中输入变量的名称
    private static final String inputName = "x_input";
    //模型中输出变量的名称
    private static final String outputName = "output";
    private static final String modePath="file:///android_asset/HARModel_motion190214002 .pb";
    TensorFlowInferenceInterface inferenceInterface;


    private float[][]storage=new float[WINDOW][SENSORNUMBER];
    static {
        //加载libtensorflow_inference.so库文件
        System.loadLibrary("tensorflow_inference");
        Log.e(TAG,"libtensorflow_inference.so库加载成功");
    }


    PredictionTF_motion(AssetManager assetManager) {
        //初始化TensorFlowInferenceInterface对象
        inferenceInterface = new TensorFlowInferenceInterface(assetManager,modePath);
        Log.e(TAG,"TensoFlow模型文件加载成功");

    }

    /**
     *  利用训练好的TensoFlow模型预测结果
     *
     * @return 返回预测结果，int数组
     */
    public float[] getPredict() {
        //  float[] inputdata = bitmapToFloatArray(bitmap,128,1);//需要将图片缩放带28*28
        //float[][] inputdata1=new float [128][1];
        //inputdata1[1]

        float[]inputdata2=new float[WINDOW*SENSORNUMBER];
       /* for (int i=0;i<9;i++){
            for (int j=0;j<128;j++){
                inputdata2[i*128+j]=storage[j][i];
            }
        }*/

            for (int j=0;j<WINDOW;j++){
                for (int i=0;i<SENSORNUMBER;i++){
                inputdata2[j*SENSORNUMBER+i]=(storage[j][i]);
            }
        }
        //将数据feed给tensorflow的输入节点
        inferenceInterface.feed(inputName, inputdata2,1,WINDOW,SENSORNUMBER);
        //运行tensorflow
        String[] outputNames = new String[] {outputName};
        inferenceInterface.run(outputNames);
        ///获取输出节点的输出信息
        float[] outputs = new float[3]; //用于存储模型的输出数据
        inferenceInterface.fetch(outputName, outputs);

        return outputs;
    }

    public void Storage(float[]gyro,float[] linearacc,float[]gravity){
        int Window=WINDOW;
        for (int i=0;i<Window-1;i++){
            for(int j=0;j<SENSORNUMBER;j++)
           storage[i][j]=storage[i+1][j];


        }
        storage[WINDOW-1][0]=Math.abs(gyro[0]);
        storage[WINDOW-1][1]=Math.abs(gyro[1]);
        storage[WINDOW-1][2]=Math.abs(gyro[2]);
        storage[WINDOW-1][3]=Math.abs(linearacc[0]);
        storage[WINDOW-1][4]=Math.abs(linearacc[1]);
       storage[WINDOW-1][5]=Math.abs(linearacc[2]);
       storage[WINDOW-1][6]=Math.abs(gravity[0]);
       storage[WINDOW-1][7]=Math.abs(gravity[1]);
       storage[WINDOW-1][8]=Math.abs(gravity[2]);

    }

}
