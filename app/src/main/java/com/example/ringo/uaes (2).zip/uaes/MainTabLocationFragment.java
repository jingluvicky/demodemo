package com.example.ringo.uaes;

/**
 * Created by ringo on 2016/11/23.
 */


import android.app.AlertDialog;
import android.app.Fragment;
import android.content.ComponentName;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.TextView;

import org.w3c.dom.Text;
import org.xutils.common.Callback;
import org.xutils.http.RequestParams;
import org.xutils.x;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MainTabLocationFragment extends Fragment {

    private static final String TAG = "MainTabLocationFragment";
    public static ImageView location;
    private DataService.MyBinder binder;
    private Handler mHandler;
    private Handler mHandlerWriteToFolie=new Handler();
    private static int zone=-1;
    private static int motion;
    public static boolean isRecord;
    private boolean[] switches = new boolean[8];


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        View view = inflater.inflate(R.layout.fragment_location, container, false);

        return view;
    }

    public void onActivityCreated(Bundle savedInstanceState) {

        final TextView txt_curZone=getActivity().findViewById(R.id.txt_curZone);

 //       final Button btn_rearPocket=(Button)getActivity().findViewById(R.id.btn_rearPocket);
   //     final Button btn_frontPocket=(Button)getActivity().findViewById(R.id.btn_frontPocket);
     //   final Button btn_inHand=(Button)getActivity().findViewById(R.id.btn_hand);
        final Switch switch_record=getActivity().findViewById(R.id.switch_record);
        final Intent bindIntent = new Intent(getActivity(), DataService.class);

        for (int i=0; i<switches.length; ++i) {
            switches[i] = true;
        }

        switch_record.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked){
                    Intent startIntent = new Intent(getActivity(), DataService.class);
                    getActivity().startService(startIntent);

                    getActivity().bindService(bindIntent, connection, getActivity().BIND_AUTO_CREATE);

                    isRecord=true;

                }
                else {
                    isRecord=false;
                   try {
                        getActivity().unbindService(connection);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        });

    /*    btn_rearPocket.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                motion=1;
                //btn_zone3.setTextColor(16);
            }
        });
        btn_frontPocket.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                motion=2;
                //btn_zone3.setTextColor(16);
            }
        });
        btn_inHand.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                motion=3;
                //btn_zone3.setTextColor(16);
            }
        });*/

        location=((ImageView)getActivity().findViewById(R.id.zoneimage));


        mHandler=new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                int walk=MainTabScanFragment.curMotion;
                ImageView img_walk=getActivity().findViewById(R.id.img_walk);
                if (walk==2){
                    img_walk.setImageResource(R.mipmap.walk_on);
                }else{
                    img_walk.setImageResource(R.mipmap.walk_off);
                }

                zone=MainTabScanFragment.curZone;

                //int zone =  MainTabConnectInfoFragment.readZone();
                if (zone==1){
                    location.setImageResource(R.mipmap.zone_1);

                    //imv_Locksign.setImageResource(R.mipmap.greenicon);
                }
                else if (zone==2){
                    location.setImageResource(R.mipmap.zone_2);

                    }
                else if (zone==3||zone==4||walk==2){
                    location.setImageResource(R.mipmap.zone_3);

                    //imv_Locksign.setImageResource(R.mipmap.redicon2);
                }else if(zone==0){
                    location.setImageResource(R.mipmap.zone_0);
                }else if (zone==255){
                    location.setImageResource(R.mipmap.zone_unknown);
                }


                mHandler.postDelayed(this,20);
            }
        }, 20);



        super.onActivityCreated(savedInstanceState);

    }





    public static int getZone(){
        return zone;
    }
    public static int getMotion(){
        return motion;
    }

    private ServiceConnection connection = new ServiceConnection() {

        @Override
        public void onServiceDisconnected(ComponentName name) {
            // TODO Auto-generated method stub

        }

        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            Log.d("Func", "onServiceConnected()");
            binder = (DataService.MyBinder) service;
            binder.setSensors(switches);
        }
    };
}



