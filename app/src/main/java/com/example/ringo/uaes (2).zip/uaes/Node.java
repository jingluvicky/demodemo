package com.example.ringo.uaes;

public class Node {
    public int RSSI;
    public double RSSI_filtered;
    public int UnfoundCounter=0;
    public boolean Validaty=false;
    public int Count=0;

}
