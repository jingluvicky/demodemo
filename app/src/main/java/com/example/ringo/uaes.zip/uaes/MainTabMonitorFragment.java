package com.example.ringo.uaes;

/**
 * Created by ringo on 2016/11/23.
 */


import android.Manifest;
import android.app.Activity;
import android.app.Fragment;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.IBinder;
import android.support.v4.app.ActivityCompat;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View.OnClickListener;

import java.io.IOException;

public class MainTabMonitorFragment extends Fragment {

    private Switch recordButton;
    private TextView recordTitle;
    private DataService.MyBinder binder;
    private boolean[] switches = new boolean[8];

    private static final int REQUEST_EXTERNAL_STORAGE = 1;
    private static String[] PERMISSIONS_STORAGE = {
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
    };

    public int  mainRSSIValueParse=255;           //主蓝牙模块场强
    public int  assistRSSIValueParse_1=255;           //辅模块1场强
    public int  assistRSSIValueParse_2=255;           //辅模块2场强
    public int  assistRSSIValueParse_3=255;           //辅模块3场强
    public int  assistRSSIValueParse_4=255;           //辅模块4场强
    public int  assistRSSIValueParse_5=255;           //辅模块5场强
    public int  assistRSSIValueParse_6=255;           //辅模块6场强
    public int  assistRSSIValueParse_7=255;           //辅模块7场强
    public int  assistRSSIValueParse_8=255;           //辅模块8场强
    public int  assistRSSIValueParse_9=255;           //辅模块9场强
    public int  AssistValidity_1=0;                    //辅模块1有效性
    public int  AssistValidity_2=0;                    //辅模块2有效性
    public int  AssistValidity_3=0;                    //辅模块3有效性
    public int  AssistValidity_4=0;                    //辅模块4有效性
    public int  AssistValidity_5=0;                    //辅模块5有效性
    public int  AssistValidity_6=0;                    //辅模块6有效性
    public int  AssistValidity_7=0;                    //辅模块7有效性
    public int  AssistValidity_8=0;                    //辅模块8有效性
    public int  AssistValidity_9=0;                    //辅模块9有效性

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        View view = inflater.inflate(R.layout.fragment_monitor, container, false);
       // View view = inflater.inflate(R.layout.gatt_services_characteristics, container, false);
        return view;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState){
        super.onActivityCreated(savedInstanceState);
        for (int i=0; i<switches.length; ++i) {
            switches[i] = true;

        }
        recordTitle=(TextView) getActivity().findViewById(R.id.txt_record);
        //scanTitle.setTextColor(100);
        recordButton=(Switch)getActivity().findViewById(R.id.recordswitch); //initialize the scanswitch
        recordButton.setTextOff("Record OFF");
        recordButton.setTextOn("Record ON");
//Start Recording
        Intent startIntent = new Intent(getActivity(), DataService.class);
        getActivity().startService(startIntent);
        Intent bindIntent = new Intent(getActivity(), DataService.class);
        getActivity().bindService(bindIntent, connection, getActivity().BIND_AUTO_CREATE);

        recordButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
            @Override
            public void onCheckedChanged(CompoundButton button,boolean isChecked){

                if(isChecked) {
                    try {

                //Start Recording
                 /*   Intent startIntent = new Intent(getActivity(), DataService.class);
                    getActivity().startService(startIntent);
                    Intent bindIntent = new Intent(getActivity(), DataService.class);
                    getActivity().bindService(bindIntent, connection, getActivity().BIND_AUTO_CREATE);
                   // BluetoothManager)getActivity().getApplicationContext().getSystemService(Context.BLUETOOTH_SERVICE);
                 */} catch (Exception e) {
                        e.printStackTrace();
                    }
                }else{
                 //Stop Recording
/*
                    try {

                        getActivity().unbindService(connection);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    Intent stopIntent = new Intent(getActivity(), DataService.class);
                    getActivity().stopService(stopIntent);
*/
                }


            }

        });

        MainTabConnectInfoFragment.setOnRSSIChangeListener(new OnRSSIChangeListener());




    }


    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        Log.e("Permisson Got",permissions.toString());
    }

    public static void verifyStoragePermissions(Activity activity) {

        int permission = ActivityCompat.checkSelfPermission(activity,
                Manifest.permission.WRITE_EXTERNAL_STORAGE);

        if (permission != PackageManager.PERMISSION_GRANTED) {
            // We don't have permission so prompt the user
            ActivityCompat.requestPermissions(
                    activity,
                    PERMISSIONS_STORAGE,
                    REQUEST_EXTERNAL_STORAGE);
        }


    }

    public void updateRSSI(int Value2parse,int Info2ID){

        if(binder!=null) {
            binder.updateRSSI(Value2parse,Info2ID);
        }

    }

    private ServiceConnection connection = new ServiceConnection() {

        @Override
        public void onServiceDisconnected(ComponentName name) {
            // TODO Auto-generated method stub

        }

        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            Log.d("Func", "onServiceConnected()");
            binder = (DataService.MyBinder) service;
            binder.setSensors(switches);
        }
    };

     class OnRSSIChangeListener implements  MainActivity.RSSIChangeListener{

        public void onMainRSSIChanged(int newmainRSSI){

           mainRSSIValueParse=newmainRSSI;           //主蓝牙模块场强
           updateRSSI(mainRSSIValueParse,0);
         }
         public  void onAssitRSSI1Changed(int newassistRSSI1){
             assistRSSIValueParse_1=newassistRSSI1;
             updateRSSI(newassistRSSI1,1);


         }
         public  void  onAssitRSSI2Changed(int newassistRSSI2){

             assistRSSIValueParse_2=newassistRSSI2;
             updateRSSI(newassistRSSI2,2);
         }

         public  void  onAssitRSSI3Changed(int newassistRSSI3){

             assistRSSIValueParse_3=newassistRSSI3;
             updateRSSI(newassistRSSI3,3);
         }


         public  void  onAssitRSSI4Changed(int newassistRSSI4){

             assistRSSIValueParse_4=newassistRSSI4;
             updateRSSI(newassistRSSI4,4);
         }

         public  void  onAssitRSSI5Changed(int newassistRSSI5){

             assistRSSIValueParse_5=newassistRSSI5;
             updateRSSI(newassistRSSI5,5);
         }

         public  void  onAssitRSSI6Changed(int newassistRSSI6){

             assistRSSIValueParse_6=newassistRSSI6;
             updateRSSI(newassistRSSI6,6);
         }

         public  void  onAssitRSSI7Changed(int newassistRSSI7){

             assistRSSIValueParse_7=newassistRSSI7;
             updateRSSI(newassistRSSI7,7);
         }

         public  void  onAssitRSSI8Changed(int newassistRSSI8){

             assistRSSIValueParse_8=newassistRSSI8;
             updateRSSI(newassistRSSI8,8);
         }

         public  void  onAssitRSSI9Changed(int newassistRSSI9){

             assistRSSIValueParse_9=newassistRSSI9;
             updateRSSI(newassistRSSI9,9);
         }
         public void onAssistValidity1Changed(int newassistValidity1){
             AssistValidity_1=newassistValidity1;
             updateRSSI(newassistValidity1,10);
         }
         public void onAssistValidity2Changed(int newassistValidity2){
             AssistValidity_2=newassistValidity2;
             updateRSSI(newassistValidity2,11);
         }
         public void onAssistValidity3Changed(int newassistValidity3){
             AssistValidity_3=newassistValidity3;
             updateRSSI(newassistValidity3,12);
         }
         public void onAssistValidity4Changed(int newassistValidity4){
             AssistValidity_4=newassistValidity4;
             updateRSSI(newassistValidity4,13);
         }
         public void onAssistValidity5Changed(int newassistValidity5){
             AssistValidity_5=newassistValidity5;
             updateRSSI(newassistValidity5,14);
         }
         public void onAssistValidity6Changed(int newassistValidity6){
             AssistValidity_6=newassistValidity6;
             updateRSSI(newassistValidity6,15);
         }
         public void onAssistValidity7Changed(int newassistValidity7){
             AssistValidity_7=newassistValidity7;
             updateRSSI(newassistValidity7,16);
         }
         public void onAssistValidity8Changed(int newassistValidity8){
             AssistValidity_8=newassistValidity8;
             updateRSSI(newassistValidity8,17);
         }
         public void onAssistValidity9Changed(int newassistValidity9){
             AssistValidity_9=newassistValidity9;
             updateRSSI(newassistValidity9,18);
         }


         public float[] getNewGravity(){

             float [] tmp=new float[3];
             if(binder!=null) {

                 tmp=binder.getNewestGravity();
             }
             return  tmp;

         }

         public float getNewProximity(){

             float  tmp=5;
             if(binder!=null) {

                 tmp=binder.getNewesProximity();
             }
             return  tmp;

         }

         public float getNewestLight(){

             float  tmp=200;
             if(binder!=null) {

                 tmp=binder.getNewLight();
             }
             return  tmp;

         }

         public float[] getNewestGyro(){

             float  []tmp=new float[3];
             if(binder!=null) {

                 tmp=binder.getNewestGyro();
             }
             return  tmp;

         }

     }



}