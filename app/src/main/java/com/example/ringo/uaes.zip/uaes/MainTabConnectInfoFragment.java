package com.example.ringo.uaes;

/**
 * Created by ringo on 2017/6/25.
 */
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Fragment;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ExpandableListView;
import android.widget.SimpleExpandableListAdapter;
import android.widget.TextView;
import android.widget.ImageView;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import java.util.concurrent.locks.Lock;

/**
 * For a given BLE device, this Activity provides the user interface to connect,
 * display data, and display GATT services and characteristics supported by the
 * device. The Activity communicates with {@code BluetoothLeService}, which in
 * turn interacts with the Bluetooth LE API.
 */
//
@SuppressLint("NewApi")
public class MainTabConnectInfoFragment  extends Fragment {
    private final static String TAG ="temp";
    private ImageView icon;
    private MainTabControlFragment.sendCMD mysendCMD;
    public static final String EXTRAS_DEVICE_NAME = "DEVICE_NAME";
    public static final String EXTRAS_DEVICE_ADDRESS = "DEVICE_ADDRESS";
    private ImageView mConnectionIcon;
    private TextView mDeviceNameTxt;
    private TextView mConnectionState;
    private TextView mDataField;
    private String mDeviceName;
    private String mDeviceAddress;
    private TextView mRSSIValueShow;
    private ExpandableListView mGattServicesList;
    private BluetoothLeService mBluetoothLeService;
    private ArrayList<ArrayList<BluetoothGattCharacteristic>> mGattCharacteristics = new ArrayList<ArrayList<BluetoothGattCharacteristic>>();
    public boolean mConnected = false;
    private BluetoothGattCharacteristic mNotifyCharacteristic;
    private int Counter;
    public  BluetoothGattCharacteristic Controlcharacteristic; //This is the charac used to interact with cc2541
    private Handler periodicHandler; //used to write characteristics 3 periodicly
    private Runnable runnable;
    public int AssistRSSI_1=255; //ASSIST RSSI 1
    public boolean RSSI_Validity_1=false; //ASSIST RSSI 1
    public int AssistRSSI_2=255; //ASSIST RSSI 2
    public boolean RSSI_Validity_2=false; //ASSIST RSSI 2
    public int AssistRSSI_3=255; //ASSIST RSSI 3
    public boolean RSSI_Validity_3=false; //ASSIST RSSI 3
    public int AssistRSSI_4=255; //ASSIST RSSI 4
    public boolean RSSI_Validity_4=false; //ASSIST RSSI 4
    public int AssistRSSI_5=255; //ASSIST RSSI 5
    public boolean RSSI_Validity_5=false; //ASSIST RSSI 5
    public int AssistRSSI_6=255; //ASSIST RSSI 6
    public boolean RSSI_Validity_6=false; //ASSIST RSSI 6
    public int AssistRSSI_7=255; //ASSIST RSSI 7
    public boolean RSSI_Validity_7=false; //ASSIST RSSI 7
    public int AssistRSSI_8=255; //ASSIST RSSI 8
    public boolean RSSI_Validity_8=false; //ASSIST RSSI 8
    public int AssistRSSI_9=255; //ASSIST RSSI 9
    public boolean RSSI_Validity_9=false; //ASSIST RSSI 9

    //*****************************
    public LockStateStrategy lockStateStrategy=new LockStateStrategy();
    public LockStateStrategy_pocket lockStateStrategy_pocket=new LockStateStrategy_pocket();
    public LockstateStrategy_p lockstateStrategy_p=new LockstateStrategy_p();
    public double AssistRSSI_1_filtered=255;
    public double AssistRSSI_2_filtered=255;
    public double AssistRSSI_3_filtered=255;
    public double AssistRSSI_4_filtered=255;
    public double AssistRSSI_5_filtered=255;
    public double AssistRSSI_6_filtered=255;
    public KalmanFilter_A1 Kalman_A1=new KalmanFilter_A1();
    public KalmanFilter_A2 Kalman_A2=new KalmanFilter_A2();
    public KalmanFilter_A3 Kalman_A3=new KalmanFilter_A3();
    public KalmanFilter_A4 Kalman_A4=new KalmanFilter_A4();
    public KalmanFilter_A5 Kalman_A5=new KalmanFilter_A5();
    public KalmanFilter_A6 Kalman_A6=new KalmanFilter_A6();


    private static float[] gravityTemp=new float[3];
    private static float[] gyroTemp=new float[3];

    private final String LIST_NAME = "NAME";
    private final String LIST_UUID = "UUID";
    public long  Lcounter;
    public int CMDCounter;
    public int CMDValue;
    public boolean connectedBefore;
    public int unfoundCounter;
    public int unfoundCounter2;
    public int unfoundCounter3;
    public int unfoundCounter4;
    public int unfoundCounter5;
    public int unfoundCounter6;
    public int unfoundCounter7;
    public int unfoundCounter8;
    public int unfoundCounter9;
    public final int scanfailureCounter=30;
    private MainTabScanFragment mainTabScanFragment;

    private static MainActivity.RSSIChangeListener mRSSIChangeListener;
    public static void setOnRSSIChangeListener(MainActivity.RSSIChangeListener listnerTemp){

        mRSSIChangeListener=listnerTemp;
    }

    //Initailize the target device info
    public void setTargetDeviceInfo(String deviceName, String deviceAddress,BluetoothManager workbluetoothManager){
        mDeviceName= deviceName;
        mDeviceAddress=deviceAddress;
        ((TextView) getActivity().findViewById(R.id.device_address)).setText( deviceName);
        PrepareBLEConnecttion(workbluetoothManager);
    }
    public void setCMDCounter(int value){

        CMDCounter=6; //Set the send times
        CMDValue=value; //Specify the control value
    }

    public void setAssistRSSI_1(int RSSItmp)
    {
        AssistRSSI_1=RSSItmp;
        unfoundCounter=0;
        mRSSIChangeListener.onAssitRSSI1Changed(RSSItmp);
        RSSI_Validity_1=true;
        mRSSIChangeListener.onAssistValidity1Changed(1);


    }

    public void setAssist_RSSI2(int RSSItmp)
    {
        AssistRSSI_2=RSSItmp;
        unfoundCounter2=0;
        mRSSIChangeListener.onAssitRSSI2Changed(RSSItmp);
        RSSI_Validity_2=true;
        mRSSIChangeListener.onAssistValidity2Changed(1);


    }

    //On AssistRSSI3 Scanned
    public void setAssistRSSI_3(int RSSItmp3)
    {
        AssistRSSI_3=RSSItmp3;
        unfoundCounter3=0;
        mRSSIChangeListener.onAssitRSSI3Changed(RSSItmp3);
        RSSI_Validity_3=true;
        mRSSIChangeListener.onAssistValidity3Changed(1);


    }


    //On AssistRSSI4 Scanned
    public void setAssistRSSI_4(int RSSItmp4)
    {
        AssistRSSI_4=RSSItmp4;
        unfoundCounter4=0;
        mRSSIChangeListener.onAssitRSSI4Changed(RSSItmp4);
        RSSI_Validity_4=true;
        mRSSIChangeListener.onAssistValidity4Changed(1);


    }

    //On AssistRSSI5 Scanned
    public void setAssistRSSI_5(int RSSItmp5)
    {
        AssistRSSI_5=RSSItmp5;
        unfoundCounter5=0;
        mRSSIChangeListener.onAssitRSSI5Changed(RSSItmp5);
        RSSI_Validity_5=true;
        mRSSIChangeListener.onAssistValidity5Changed(1);

    }

    //On AssistRSSI6 Scanned
    public void setAssistRSSI_6(int RSSItmp6)
    {
        AssistRSSI_6=RSSItmp6;
        unfoundCounter6=0;
        mRSSIChangeListener.onAssitRSSI6Changed(RSSItmp6);
        RSSI_Validity_6=true;
        mRSSIChangeListener.onAssistValidity6Changed(1);


    }

    //On AssistRSSI7 Scanned
    public void setAssistRSSI_7(int RSSItmp7)
    {
        AssistRSSI_7=RSSItmp7;
        unfoundCounter7=0;
        mRSSIChangeListener.onAssitRSSI7Changed(RSSItmp7);
        RSSI_Validity_7=true;
        mRSSIChangeListener.onAssistValidity7Changed(1);

    }

    //On AssistRSSI8 Scanned
    public void setAssistRSSI_8(int RSSItmp8)
    {
        AssistRSSI_8=RSSItmp8;
        unfoundCounter8=0;
        mRSSIChangeListener.onAssitRSSI8Changed(RSSItmp8);
        RSSI_Validity_8=true;
        mRSSIChangeListener.onAssistValidity8Changed(1);

    }



    //On AssistRSSI9 Scanned
    public void setAssistRSSI_9(int RSSItmp9)
    {
        AssistRSSI_9=RSSItmp9;
        unfoundCounter9=0;
        mRSSIChangeListener.onAssitRSSI9Changed(RSSItmp9);
        RSSI_Validity_9=true;
        mRSSIChangeListener.onAssistValidity9Changed(1);


    }





    public void stopConnecttion(){

        if(mConnected){
            periodicHandler.removeCallbacks(runnable);
            mBluetoothLeService.disconnect();}

        clearUI();


    }
    //Write Value of Control Characteritics
    public void writeControlChacValue(int value){

        byte[] atemp=new byte[]{0,0,0};

        String sTemp2;
        String sTemp=String.valueOf(CMDValue);//CMD
        if(mBluetoothLeService.getRssiVal())
        {
            sTemp2=String.valueOf(-mBluetoothLeService.myRSSI);
        }else{
            sTemp2="255";


        }//refresh RSSI succeed

        if(CMDCounter>0){
            atemp[0]=sTemp.getBytes()[0];
            CMDCounter--;}
        else{
            CMDValue=0;
            atemp[0]=sTemp.getBytes()[0];

        }
        atemp[1]=sTemp2.getBytes()[0];
        Controlcharacteristic.setValue(atemp);
        mBluetoothLeService.wirteCharacteristic(Controlcharacteristic);

    }

    // Code to manage Service lifecycle.
    private final ServiceConnection mServiceConnection = new ServiceConnection() {

        @Override
        public void onServiceConnected(ComponentName componentName,
                                       IBinder service) {
            mBluetoothLeService = ((BluetoothLeService.LocalBinder) service)
                    .getService();
            if (!mBluetoothLeService.initialize()) {
                Log.e(TAG, "Unable to initialize Bluetooth");
                getActivity().finish();
            }
            // Automatically connects to the device upon successful start-up
            // initialization.
            mBluetoothLeService.connect(mDeviceAddress);
        }

        @Override
        public void onServiceDisconnected(ComponentName componentName) {
            mBluetoothLeService = null;
        }
    };

    // Handles various events fired by the Service.
    // ACTION_GATT_CONNECTED: connected to a GATT server.
    // ACTION_GATT_DISCONNECTED: disconnected from a GATT server.
    // ACTION_GATT_SERVICES_DISCOVERED: discovered GATT services.
    // ACTION_DATA_AVAILABLE: received data from the device. This can be a
    // result of read
    // or notification operations.
    private final BroadcastReceiver mGattUpdateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();
            System.out.println("action = " + action);
            if (BluetoothLeService.ACTION_GATT_CONNECTED.equals(action)) {
                Log.d(TAG, "zyl : ************STATE_CONNECTED*************");
                mConnected = true;
                updateConnectionState(R.string.connected);
                connectedBefore=true;
                //  mConnectionState.setTextColor(Color.GREEN);
                mConnectionIcon.setImageResource(R.mipmap.greenicon2);
                getActivity().invalidateOptionsMenu();
            } else if (BluetoothLeService.ACTION_GATT_DISCONNECTED
                    .equals(action)) {
                Log.d(TAG, "zyl : ************STATE_DISCONNECTED*************");

                mConnected = false;
                updateConnectionState(R.string.disconnected);
                //mConnectionState.setTextColor(Color.RED);
                mConnectionIcon.setImageResource(R.mipmap.redicon2);
                mRSSIValueShow.setText("0dB");
                getActivity().invalidateOptionsMenu();
                clearUI();
                // 断开连接后，断开服务，解绑广播，扫描连接后重新建立链接
                getActivity().unbindService(mServiceConnection);
                mBluetoothLeService.close();
                stopConnecttion();
                mBluetoothLeService = null;
                // 断开连接后，直接调用关闭开关的方法,十秒后再去打开
                Message msg = new Message();
                handler.sendMessage(msg);
            } else if (BluetoothLeService.ACTION_GATT_SERVICES_DISCOVERED
                    .equals(action)) {
                // Show all the supported services and characteristics on the
                // user interface.
                displayGattServices(mBluetoothLeService
                        .getSupportedGattServices());
            } else if (BluetoothLeService.ACTION_DATA_AVAILABLE.equals(action)) {
                displayData(intent
                        .getStringExtra(BluetoothLeService.EXTRA_DATA));
            }
        }
    };

    private Handler handler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            mainTabScanFragment.stopBleConnect();
            try {
                Thread.sleep(10*1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            mainTabScanFragment.startBleConnect();
        }
    };

    // If a given GATT characteristic is selected, check for supported features.
    // This sample
    // demonstrates 'Read' and 'Notify' features. See
    // http://d.android.com/reference/android/bluetooth/BluetoothGatt.html for
    // the complete
    // list of supported characteristic features.
    private final ExpandableListView.OnChildClickListener servicesListClickListner = new ExpandableListView.OnChildClickListener() {
        @Override
        public boolean onChildClick(ExpandableListView parent, View v,
                                    int groupPosition, int childPosition, long id) {

            if (mGattCharacteristics != null) {
                final BluetoothGattCharacteristic characteristic = mGattCharacteristics
                        .get(groupPosition).get(childPosition);
                final int charaProp = characteristic.getProperties();
                System.out.println("charaProp = " + charaProp + ",UUID = "
                        + characteristic.getUuid().toString());
                Random r = new Random();

                if (characteristic.getUuid().toString()
                        .equals("0000fff2-0000-1000-8000-00805f9b34fb")) {
                    int time= 0;
                    while((time=r.nextInt(9))<=0){

                    }

                    String data = time+","+"1,,,,,";
                    characteristic.setValue(data.getBytes());
                    mBluetoothLeService.wirteCharacteristic(characteristic);
                }
                if (characteristic.getUuid().toString()
                        .equals("0000fff1-0000-1000-8000-00805f9b34fb")) {
                    int R = r.nextInt(255);
                    int G = r.nextInt(255);
                    int B = r.nextInt(255);
                    int BB = r.nextInt(100);
                    String data = R + "," + G + "," + B + "," + BB;
                    while (data.length() < 18) {
                        data += ",";
                    }
                    System.out.println(data);
                    characteristic.setValue(data.getBytes());
                    mBluetoothLeService.wirteCharacteristic(characteristic);
                }
                if (characteristic.getUuid().toString()
                        .equals("0000fff3-0000-1000-8000-00805f9b34fb")) {
                    int R = r.nextInt(255);
                    int G = r.nextInt(255);
                    int B = r.nextInt(255);
                    int BB = r.nextInt(100);
                    String data = R + "," + G + "," + B + "," + BB;
                    while (data.length() < 18) {
                        data += ",";
                    }
                    System.out.println("RT");
                    characteristic.setValue("RT".getBytes());
                    mBluetoothLeService.wirteCharacteristic(characteristic);
                }
                if (characteristic.getUuid().toString()
                        .equals("0000fff5-0000-1000-8000-00805f9b34fb")) {
                    characteristic.setValue("S".getBytes());
                    mBluetoothLeService.wirteCharacteristic(characteristic);
                    System.out.println("send S");
                } else {

                    if ((charaProp & BluetoothGattCharacteristic.PROPERTY_READ) > 0) {
                        // If there is an active notification on a
                        // characteristic, clear
                        // it first so it doesn't update the data field on the
                        // user interface.
                        if (mNotifyCharacteristic != null) {
                            mBluetoothLeService.setCharacteristicNotification(
                                    mNotifyCharacteristic, false);
                            mNotifyCharacteristic = null;
                        }
                        mBluetoothLeService.readCharacteristic(characteristic);

                    }
                }
                if ((charaProp | BluetoothGattCharacteristic.PROPERTY_NOTIFY) > 0) {

                    if (characteristic.getUuid().toString().equals("0000fff6-0000-1000-8000-00805f9b34fb")||characteristic.getUuid().toString().equals("0000fff4-0000-1000-8000-00805f9b34fb")) {
                        System.out.println("enable notification");
                        mNotifyCharacteristic = characteristic;
                        mBluetoothLeService.setCharacteristicNotification(
                                characteristic, true);

                    }
                }

                return true;
            }
            return false;
        }
    };

    private void clearUI() {
        mGattServicesList.setAdapter((SimpleExpandableListAdapter) null);
        mDataField.setText(R.string.no_data);
        mDeviceName =  " ";//intent.getStringExtra(EXTRAS_DEVICE_NAME);
        mDeviceAddress = " ";// intent.getStringExtra(EXTRAS_DEVICE_ADDRESS);
        mRSSIValueShow.setText("0dB");
        // Sets up UI references.
        mDeviceNameTxt.setText(" ");


    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        View view = inflater.inflate(R.layout.gatt_services_characteristics, container, false);


        return view;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        //   super.onCreate(savedInstanceState);
        // getActivity().setContentView(R.layout.gatt_services_characteristics);

        // final Intent intent = getActivity().getIntent();

        mainTabScanFragment = new MainTabScanFragment();
        mDeviceName =  "Hello world";//intent.getStringExtra(EXTRAS_DEVICE_NAME);
        mDeviceAddress = "Hello world2";// intent.getStringExtra(EXTRAS_DEVICE_ADDRESS);
        mConnectionIcon=((ImageView)getActivity().findViewById(R.id.connectStateIcon));
        // Sets up UI references.
        mDeviceNameTxt=((TextView) getActivity().findViewById(R.id.device_address));
        mGattServicesList = (ExpandableListView) getActivity().findViewById(R.id.gatt_services_list);
        mGattServicesList.setOnChildClickListener(servicesListClickListner);
        mRSSIValueShow =((TextView) getActivity().findViewById(R.id.connecttedRSSI));

        //  mConnectionState = (TextView) getActivity().findViewById(R.id.connection_state);
        mDataField = (TextView) getActivity().findViewById(R.id.data_value);
        //getActivity().getActionBar().setTitle(mDeviceName);
        //getActivity().getActionBar().setDisplayHomeAsUpEnabled(true);

        super.onActivityCreated(savedInstanceState);
    }
    public void PrepareBLEConnecttion(BluetoothManager workbluetoothManager){


        Intent gattServiceIntent = new Intent(getActivity(), BluetoothLeService.class);
        boolean bll = getActivity().bindService(gattServiceIntent, mServiceConnection,
                getActivity().BIND_AUTO_CREATE);
        if( mBluetoothLeService==null )
        {
            mBluetoothLeService=new BluetoothLeService();
            mBluetoothLeService.setBLEManager(workbluetoothManager);


        }
        if(connectedBefore){
            mBluetoothLeService.onDestroy();
            mBluetoothLeService=new BluetoothLeService();
            mBluetoothLeService.setBLEManager(workbluetoothManager);
            mBluetoothLeService.InitBluetoothAdpter();
        }

        if( mBluetoothLeService.connect(mDeviceAddress)){
            mDeviceNameTxt.setText(mDeviceName);
            //mConnectionState.setText("Connected Successfully");
            //mConnectionState.setTextColor(Color.GREEN);
            mConnectionIcon.setImageResource(R.mipmap.greenicon2);
            mDataField .setText(mDeviceAddress);
        }else{
            mDeviceNameTxt.setText(mDeviceName);
            //mConnectionState.setText("Connected Failed");
            // mConnectionState.setTextColor(Color.RED);
            mConnectionIcon.setImageResource(R.mipmap.redicon2);
            mDataField .setText(mDeviceAddress);
        }


        //  if (bll) {
        //    System.out.println("---------------");
        //  } else {
        // System.out.println("===============");
        //  }

    }
    @Override
    public void onResume() {
        super.onResume();
        getActivity().registerReceiver(mGattUpdateReceiver, makeGattUpdateIntentFilter());
        if (mBluetoothLeService != null) {
            final boolean result = mBluetoothLeService.connect(mDeviceAddress);
            Log.d(TAG, "Connect request result=" + result);
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        getActivity().unregisterReceiver(mGattUpdateReceiver);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        getActivity().unbindService(mServiceConnection);
        mBluetoothLeService = null;
    }
/*
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getActivity().getMenuInflater().inflate(R.menu.gatt_services, menu);
        if (mConnected) {
            menu.findItem(R.id.menu_connect).setVisible(false);
            menu.findItem(R.id.menu_disconnect).setVisible(true);
        } else {
            menu.findItem(R.id.menu_connect).setVisible(true);
            menu.findItem(R.id.menu_disconnect).setVisible(false);
        }
        return true;
    }*/

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_connect:
                mBluetoothLeService.connect(mDeviceAddress);
                return true;
            case R.id.menu_disconnect:
                mBluetoothLeService.disconnect();
                return true;
            case android.R.id.home:
                getActivity().onBackPressed();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void updateConnectionState(final int resourceId) {
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                // mConnectionState.setText(resourceId);
            }
        });
    }

    private void displayData(String data) {
        if (data != null) {
            mDataField.setText(data);
        }
    }








    // Demonstrates how to iterate through the supported GATT
    // Services/Characteristics.
    // In this sample, we populate the data structure that is bound to the
    // ExpandableListView
    // on the UI.
    private void displayGattServices(List<BluetoothGattService> gattServices) {
        if (gattServices == null)
            return;
        final KalmanFilter Kalman_main=new KalmanFilter();

        String uuid = null;
        String unknownServiceString = getResources().getString(
                R.string.unknown_service);
        String unknownCharaString = getResources().getString(
                R.string.unknown_characteristic);
        ArrayList<HashMap<String, String>> gattServiceData = new ArrayList<HashMap<String, String>>();
        ArrayList<ArrayList<HashMap<String, String>>> gattCharacteristicData = new ArrayList<ArrayList<HashMap<String, String>>>();
        mGattCharacteristics = new ArrayList<ArrayList<BluetoothGattCharacteristic>>();
        icon=(ImageView)getActivity().findViewById(R.id.lockpoint);
        // Loops through available GATT Services.
        for (BluetoothGattService gattService : gattServices) {
            HashMap<String, String> currentServiceData = new HashMap<String, String>();
            uuid = gattService.getUuid().toString();
            currentServiceData.put(LIST_NAME,
                    SampleGattAttributes.lookup(uuid, unknownServiceString));
            currentServiceData.put(LIST_UUID, uuid);
            gattServiceData.add(currentServiceData);

            ArrayList<HashMap<String, String>> gattCharacteristicGroupData = new ArrayList<HashMap<String, String>>();
            List<BluetoothGattCharacteristic> gattCharacteristics = gattService
                    .getCharacteristics();
            ArrayList<BluetoothGattCharacteristic> charas = new ArrayList<BluetoothGattCharacteristic>();

            // Loops through available Characteristics.
            for (BluetoothGattCharacteristic gattCharacteristic : gattCharacteristics) {
                charas.add(gattCharacteristic);
                HashMap<String, String> currentCharaData = new HashMap<String, String>();
                uuid = gattCharacteristic.getUuid().toString();
                currentCharaData.put(LIST_NAME,
                        SampleGattAttributes.lookup(uuid, unknownCharaString));
                currentCharaData.put(LIST_UUID, uuid);
                gattCharacteristicGroupData.add(currentCharaData);

                if(gattCharacteristic.getUuid().toString().equals("0000fff3-0000-1000-8000-00805f9b34fb")) {
                    Controlcharacteristic = gattCharacteristic;
                    periodicHandler=new Handler();
                    runnable  = new Runnable(){
                        @Override
                        public void run() {
                            Log.d(TAG, "run: ******************" + (mBluetoothLeService == null));

                            if (!(mBluetoothLeService == null)) {
                                //change to 13 byte for multinode test cmd, main_rssi, assist_rssi1-8, assit_validity(9)
                                byte[] atemp = new byte[]{0, 0, 0, 0, 0,
                                        0,0, 0, 0, 0,
                                        0,0, 0, 0, 0,
                                        0,0, 0, 0, 0,};
                                int iTemp = 0;//=Math.abs(mBluetoothLeService.myRSSI);
                                double iTemp_filtered=0;
                                String sTemp;//CMD
                                String sTemp2;

                                if (mBluetoothLeService.getRssiVal()) {

                                    iTemp = Math.abs(mBluetoothLeService.getNewestRssi());
                                    iTemp_filtered=Kalman_main.FilteredRSSI(iTemp);
                                    mRSSIChangeListener.onMainRSSIChanged(iTemp);
                                    if (Lcounter % 5 == 0) {
                                        mRSSIValueShow.setText("-" + String.valueOf(iTemp) + "dB");
                                    }
                                    sTemp2 = String.valueOf(iTemp);
                                } else {
                                    iTemp = Math.abs(mBluetoothLeService.getNewestRssi());
                                }
                                //refresh RSSI succeed11


                                if (unfoundCounter > scanfailureCounter) {

                                    unfoundCounter = scanfailureCounter;
                                    RSSI_Validity_1=false;
                                    mRSSIChangeListener.onAssistValidity1Changed(0);
                                }

                                if (unfoundCounter2 > scanfailureCounter) {

                                    unfoundCounter2 = scanfailureCounter;
                                    RSSI_Validity_2=false;
                                    mRSSIChangeListener.onAssistValidity2Changed(0);
                                }

                                if (unfoundCounter3 > scanfailureCounter) {

                                    unfoundCounter3 = scanfailureCounter;
                                    RSSI_Validity_3=false;
                                    mRSSIChangeListener.onAssistValidity3Changed(0);
                                }

                                if (unfoundCounter4 > scanfailureCounter) {

                                    unfoundCounter4 = scanfailureCounter;
                                    RSSI_Validity_4=false;
                                    mRSSIChangeListener.onAssistValidity4Changed(0);
                                }

                                if (unfoundCounter5 > scanfailureCounter) {

                                    unfoundCounter5 = scanfailureCounter;
                                    RSSI_Validity_5=false;
                                    mRSSIChangeListener.onAssistValidity5Changed(0);
                                }

                                if (unfoundCounter6 > scanfailureCounter) {

                                    unfoundCounter6 = scanfailureCounter;
                                    RSSI_Validity_6=false;
                                    mRSSIChangeListener.onAssistValidity6Changed(0);
                                }

                                if (unfoundCounter7 > scanfailureCounter) {

                                    unfoundCounter7 = scanfailureCounter;
                                    RSSI_Validity_7=false;
                                    mRSSIChangeListener.onAssistValidity7Changed(0);
                                }

                                if (unfoundCounter8 > scanfailureCounter) {

                                    unfoundCounter8 = scanfailureCounter;
                                    RSSI_Validity_8=false;
                                    mRSSIChangeListener.onAssistValidity8Changed(0);
                                }

                                if (unfoundCounter9 > scanfailureCounter) {

                                    unfoundCounter9 = scanfailureCounter;
                                    RSSI_Validity_9=false;
                                    mRSSIChangeListener.onAssistValidity9Changed(0);
                                }

                                int iValidity_1=0;
                                if(RSSI_Validity_8)
                                {
                                    iValidity_1+=128;
                                }
                                if(RSSI_Validity_7)
                                {
                                    iValidity_1+=64;
                                }
                                if(RSSI_Validity_6)
                                {
                                    iValidity_1+=32;
                                }
                                if(RSSI_Validity_5)
                                {
                                    iValidity_1+=16;
                                }
                                if(RSSI_Validity_4)
                                {
                                    iValidity_1+=8;
                                }
                                if(RSSI_Validity_3)
                                {
                                    iValidity_1+=4;
                                }
                                if(RSSI_Validity_2)
                                {
                                    iValidity_1+=2;
                                }
                                if(RSSI_Validity_1)
                                {
                                    iValidity_1+=1;
                                }
                                int iValidity_2=0;
                                if(RSSI_Validity_9)
                                {
                                    iValidity_2+=1;
                                }
                                float light=mRSSIChangeListener.getNewestLight();
                                gyroTemp=mRSSIChangeListener.getNewestGyro();
                               // Log.d("gyrolisten",gyro[0]+"  "+gyro[1]+"  "+gyro[2]+"  ");
                                // double sportSum=sport[0]*sport[0]+sport[1]*sport[1];

                                // Log.d("sport"," "+sport[0]+"  "+sport[1]+"  "+sport[2]);
                                AssistRSSI_1_filtered=Kalman_A1.FilteredRSSI(AssistRSSI_1,RSSI_Validity_1);
                                AssistRSSI_2_filtered=Kalman_A2.FilteredRSSI(AssistRSSI_2,RSSI_Validity_2);
                                AssistRSSI_3_filtered=Kalman_A3.FilteredRSSI(AssistRSSI_3,RSSI_Validity_3);
                                AssistRSSI_4_filtered=Kalman_A4.FilteredRSSI(AssistRSSI_4,RSSI_Validity_4);
                                AssistRSSI_5_filtered=Kalman_A5.FilteredRSSI(AssistRSSI_5,RSSI_Validity_5);
                                AssistRSSI_6_filtered=Kalman_A6.FilteredRSSI(AssistRSSI_6,RSSI_Validity_6);
                                float proximitytmp = mRSSIChangeListener.getNewProximity();
                                //float[] gravityTmp = new float[3];

                                float lightTmp = mRSSIChangeListener.getNewestLight();
                                gravityTemp = mRSSIChangeListener.getNewGravity();
                                double []temp11=lockstateStrategy_p.LockState(iTemp_filtered,-AssistRSSI_1_filtered,-AssistRSSI_2_filtered,true,RSSI_Validity_1,RSSI_Validity_2,light,gravityTemp,proximitytmp,gyroTemp);
                                double obstacle=lockstateStrategy_p.curHumanObstacle;
                                double[]LockState=new double[5];
                                if (obstacle==1) {
                                    //Log.d("proximity",proximitytmp+"   ");
                                    //double []posture=Posture.posture(gravityTemp[0],gravityTemp[1],gravityTemp[2],gyroTemp[0],gyroTemp[1],gyroTemp[2]);
                                    //Log.d("posture",posture[0]+" "+posture[1]+"  "+posture[2]);
                                    LockState = lockStateStrategy_pocket.LockState(iTemp_filtered, -AssistRSSI_1_filtered, -AssistRSSI_2_filtered, true, RSSI_Validity_1, RSSI_Validity_2, light, gravityTemp, proximitytmp);
                                    //double[] LockState=lockStateStrategy_pocket.LockState(iTemp_filtered,-AssistRSSI_1_filtered,-AssistRSSI_2_filtered,true,RSSI_Validity_1,RSSI_Validity_2,light,gravityTemp,proximitytmp);
                                }else{
                                    LockState = lockStateStrategy.LockState(iTemp_filtered, -AssistRSSI_1_filtered, -AssistRSSI_2_filtered, true, RSSI_Validity_1, RSSI_Validity_2, light, gravityTemp, proximitytmp,gyroTemp);

                                }
                                Integer IO = new Integer(iTemp);// 4A3-1

                                Integer IO2 = new Integer(-AssistRSSI_2);//4A3-2
                                Integer IO3 = new Integer(iTemp);//4a3-4
                                Integer IO4 = new Integer(-(int)AssistRSSI_1_filtered);//4A3-8
                                Integer IO5 = new Integer(-(int)AssistRSSI_3_filtered);//4A8-1
                                Integer IO6 = new Integer(-(int)AssistRSSI_4_filtered);//4A8-2
                                Integer IO7 = new Integer((int)LockState[3]);//4A8-3
                                Log.d("lockstate3",LockState[3]+"  ");
                                //Integer IO5 = new Integer(-AssistRSSI_4);//4A9-2
                                //Integer IO6 = new Integer(-AssistRSSI_5);//4A9-3
                                //Integer IO7 = new Integer(-AssistRSSI_6);//4A9-4

                                //Integer IO8 = new Integer(-AssistRSSI_7);
                                // Integer IO9 = new Integer(-AssistRSSI_8);
                                //Integer IO10 = new Integer(-AssistRSSI_9);
                                Integer IO8=new Integer(-(int)AssistRSSI_1_filtered);//4A8-4
                                Integer IO9=new Integer(-(int)AssistRSSI_2_filtered);//4A8-5
                                Integer IO10=new Integer((int)LockState[1]);//4A8-6

                                Integer IO11 = new Integer((int)LockState[2]);//4A8-7
                                Integer IO12 = new Integer((int)iValidity_1);//4a8-8
                                Integer IO13=new Integer((int)iTemp_filtered);//4a9-2


                                Integer IO14 = new Integer((int)LockState[0]);//4A9-3
                                Integer IO15 = new Integer(-(int)AssistRSSI_3);//4A9-4
                                Integer IO16 = new Integer(-(int)AssistRSSI_4);//4A9-5
                                Integer IO17 = new Integer(-(int)AssistRSSI_5);//4A9-6
                                Integer IO18 = new Integer((int)LockState[4]);//4A9-7

                                //Integer IO18 = new Integer(-(int)AssistRSSI_6);//4A9-7
                                Integer IO19 = new Integer(-(int)AssistRSSI_2_filtered);//4A3-3




                                if ((int)LockState[0]==3)
                                {
                                    icon.setImageResource(R.mipmap.redicon2);
                                    //Toast.makeText(getActivity(), "Lock Cmd", Toast.LENGTH_SHORT).show();
                                   //  mysendCMD.sendControlCMD(1);

                                }else if ((int)LockState[0]==1){
                                    //Toast.makeText(getActivity(), "UnLock Cmd", Toast.LENGTH_SHORT).show();

                                    icon.setImageResource(R.mipmap.greenicon);
                                    //mysendCMD.sendControlCMD(2);
                                }


                                if (CMDCounter > 0) {

                                    CMDCounter--;
                                } else {
                                    CMDValue = 0;
                                }
                                gravityTemp = new float[3];
                                proximitytmp = mRSSIChangeListener.getNewProximity();
                                lightTmp = mRSSIChangeListener.getNewestLight();
                                gravityTemp = mRSSIChangeListener.getNewGravity();
                                int inPocket;
                                if (proximitytmp < 2 && Math.abs(gravityTemp[1]) > 8 && lightTmp < 15) {
                                    inPocket = 16;
                                } else {
                                    inPocket = 0;
                                }
                                Integer IO_0 = new Integer(CMDValue + inPocket);

                                atemp[0] = IO_0.byteValue();
                                atemp[1] = IO.byteValue();
                                atemp[2] = IO2.byteValue();
                                atemp[3] = IO3.byteValue();
                                atemp[4] = IO4.byteValue();
                                atemp[5] = IO5.byteValue();
                                atemp[6] = IO6.byteValue();
                                atemp[7] = IO7.byteValue();
                                atemp[8] = IO8.byteValue();
                                atemp[9] = IO9.byteValue();
                                atemp[10] = IO10.byteValue();
                                atemp[11] = IO11.byteValue();
                                atemp[12] = IO12.byteValue();
                                atemp[13] = IO13.byteValue();
                                atemp[14] = IO14.byteValue();
                                atemp[15] = IO15.byteValue();
                                atemp[16] = IO16.byteValue();
                                atemp[17] = IO17.byteValue();
                                atemp[18] = IO18.byteValue();
                                atemp[19] = IO19.byteValue();
                               /*  atemp[20] = IO20.byteValue();
                                atemp[21] = IO21.byteValue();
*/

                                sTemp = String.valueOf(0);
                                sTemp2 = String.valueOf(Math.abs(mBluetoothLeService.getNewestRssi()));
                                if (Math.abs(mBluetoothLeService.getNewestRssi()) < 100) {
                                    sTemp2 = sTemp + sTemp + sTemp2;
                                } else {
                                    sTemp2 = sTemp + sTemp2;
                                }
                                Lcounter++;
                                unfoundCounter++;
                                unfoundCounter2++;
                                unfoundCounter3++;
                                unfoundCounter4++;
                                unfoundCounter5++;
                                unfoundCounter6++;
                                unfoundCounter7++;
                                unfoundCounter8++;
                                unfoundCounter9++;


                                Controlcharacteristic.setValue(atemp);
                                mBluetoothLeService.wirteCharacteristic(Controlcharacteristic);
                                if (Lcounter > 1000) {
                                    Lcounter = 0;
                                }
                                periodicHandler.postDelayed(this, 30);
                                // 50是延时时长
                            }
                        }
                    };
                    periodicHandler.postDelayed( runnable,30);

                }


            }
            mGattCharacteristics.add(charas);
            gattCharacteristicData.add(gattCharacteristicGroupData);
        }

        SimpleExpandableListAdapter gattServiceAdapter = new SimpleExpandableListAdapter(
                getActivity(), gattServiceData,
                android.R.layout.simple_expandable_list_item_2, new String[] {
                LIST_NAME, LIST_UUID }, new int[] { android.R.id.text1,
                android.R.id.text2 }, gattCharacteristicData,
                android.R.layout.simple_expandable_list_item_2, new String[] {
                LIST_NAME, LIST_UUID }, new int[] { android.R.id.text1,
                android.R.id.text2 });
        mGattServicesList.setAdapter(gattServiceAdapter);
    }

    private static IntentFilter makeGattUpdateIntentFilter() {
        final IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(BluetoothLeService.ACTION_GATT_CONNECTED);
        intentFilter.addAction(BluetoothLeService.ACTION_GATT_DISCONNECTED);
        intentFilter.addAction(BluetoothLeService.ACTION_GATT_SERVICES_DISCOVERED);
        intentFilter.addAction(BluetoothLeService.ACTION_DATA_AVAILABLE);
        intentFilter.addAction(BluetoothLeService.EXTRA_DATA);
        return intentFilter;
    }





}

