package com.example.ringo.uaes;

import android.util.Log;

public class LockStateStrategy {
  static String LockStateStorage="0";
  static final Integer Window=50;
  static final Integer CalA1=60;
  static final Integer CalA2=65;
  static final Integer CalA3=60;
  static final Integer CalMain=72;
  static Integer curWindow=0;
  //buffer
  static double[] mainStorage=new double[Window];
  static double[] A1Storage=new double[Window];
  static double[] A2Storage=new double[Window];
  static double[] A3Storage=new double[Window];
  static float[] gyroStorage=new float [Window];
  //RSSI
  static double main;
  static double A1;
  static double A2;

 //valid
  static int validMain=0, validA1=0, validA2=0;
  //Sensor
  static Integer Q_gradient=20;
  static float light=0;
  static double proximity=0;
  static double humanObstacle=0;
  static float[] gravity=new float[3];
  static double gradientMain,gradientA1,gradientA2;
  static double curHumanObstacle;
static float gyro=0;

  LockStateStrategy(){
    for (int i=0;i<Window;i++){
      mainStorage[i]=0;
      A1Storage[i]=0;
      A2Storage[i]=0;
      gyroStorage[i]=0;

    }
  }
  public void RSSIStorage(double main,double A1,double A2,float gyrosum){

    for (int i=Window-1;i>0;i--){
      mainStorage[i]=mainStorage[i-1];
      A1Storage[i]=A1Storage[i-1];
      A2Storage[i]=A2Storage[i-1];
      gyroStorage[i]=gyro;
    }
    mainStorage[0]=main;
    A1Storage[0]=A1;
    A2Storage[0]=A2;
    gyroStorage[0]=gyrosum;

  }


  public double[] LockState(double main, double A1, double A2, boolean bvalidMain, boolean bvalidA1, boolean bvalidA2, float light, float []gravity, float proximity,float[] gyrotemp){
    double[] temp=new double[5];
    if (bvalidMain) validMain=1;
    if (bvalidA1)validA1=1;
    if(bvalidA2)validA2=1;

    double gradient=(main-this.main)*validMain;//+(A1-this.A1)*validA1+(A2-this.A2)*validA2+(A3-this.A3)*validA3)/(validA3+validA2+validA1+validMain);
    this.proximity=proximity;
    this.gravity=gravity;
    this.gyro=gyro;
    this.main=main;
    this.A1=A1;
    this.A2=A2;

    this.validMain=validMain;
    this.validA1=validA1;
    this.validA2=validA2;
    this.gyro=gyrotemp[0]*gyrotemp[0]+gyrotemp[1]*gyrotemp[1]+gyrotemp[2]*gyrotemp[2];
    this.light=light;
    RSSIStorage(main,A1,A2,gyro);
    //double possiMain=PossibilityMain();

    gradientMain=-(this.main-mainStorage[Window-1]);
    gradientA1=-(this.A1-A1Storage[Window-1]);
    gradientA2=-(this.A2-A2Storage[Window-1]);

 //是否持续下降或上升踏入惹热

      int keepMain = 1, keepA1 = 1, keepA2 = 1, keepA3 = 1;

    temp[1]=keepA1;
    temp[2]=keepA2;
    temp[3]=keepA3;
    //strategy
    //Log.d("possi",possiMain+temp[1]+temp[2]+temp[3]+"  ");
    Log.d("light",light+"  ");
   //bound define

    //if (light>2){inPocket=0;}
    double possi=temp[1]+temp[2]+temp[3];

    curHumanObstacle=HumanObstacle(curHumanObstacle,gradient);
    temp[3]=curHumanObstacle;
    //curHumanObstacle=0;
    //Log.d("gradientsum",gradient+"  ");
      Log.d("obstacle",curHumanObstacle+"  ");
    int limitMain=62;
    int limitA1=50;
    int limitA2=55;

    double gradientStandard=-5;
    Log.d("gradienta1",gradientA1+"  ");


    double score1=0;
    double score2=0;

    //if  (main<limitMain/*||(main<limitMain+5 && gradientMain<gradientStandard*/)score=score+1;
    if(A1<limitA1)score1=+1;
    else if (A1<limitA1+10){score1=2;}
    else score1=3;

    if(A2<limitA2)score2=1;
    else if (A2<limitA2+10){score2=2;}
    else score2=3;
    //if ( A2<limitA2-5/*||    (A2<limitA2+5&&gradientA2<gradientStandard*/) score=score+1;else if (A2<limitA2){score=score+2;}
    if (score1==1) temp[1]=1;
    if (score1==2) temp[1]=2;
    if (score1==3) temp[1]=3;
    if (score2==1) temp[2]=1;
    if (score2==2) temp[2]=2;
    if (score2==3) temp[2]=3;


    // Zone 1
    if ((((A2-A1<-8 && A2<limitA2-5)||((A2-A1>-8)&&score1==1)||score2==1||score1+score2<=3)&&main<70)||
            gradientMain>7||
            ((score1+score2==6) && main<=58))
    {
      Log.d("gradientM;ain",gradientMain+"  ");
      LockStateStorage="1";
      temp[0]=1;
      temp[4]=1;
  }
  //Zone 3
    else if((score1+score2==6)||

            ( Math.abs(A1-A2)>=8 && main>70&& score1+score2>=5)||
             (Math.abs(A1-A2)<8  && main >65&&score1+score2>=5)){
    LockStateStorage="3";
      temp[4]=3;
      temp[0]=3;
    }
    //Zone 2
    else temp[0]=2;
if( LockStateStorage.equals("1"))temp[4]=1;
else temp[4]=3;
    return temp;
  }
  private double HumanObstacle(double curHumanObstacle,double gradient ){
    //double gradient=(gradientA1+gradientA2+gradientA3)/3;
    float gyrosum=0;
    for (int i=1;i<Window;i++){
      gyrosum=gyrosum+gyroStorage[i];
    }
    Log.d("gyro",gyrosum+"  ");
    Log.d("gradientOb",gradient*100+" " );
    if (gyrosum>30&&light<10 &&proximity<2&&Math.abs(gravity[1])>8/* &&gradient>0.3*/){
      return 1;
    }
    if (gradient <-1 && proximity>2&&curHumanObstacle>0){
      return curHumanObstacle-0.05;
    }
    if ( proximity>2 && curHumanObstacle>0){
      return curHumanObstacle-0.05;
    }
    return curHumanObstacle;
  }
//PossibilityMain
  public double PossibilityMain(){

    //gradientMain=-(this.main-mainStorage[Window-1])*validMain*7*Q_gradient/100;
    double distance=(72-this.main)*10;

    if (gradientMain>Q_gradient) gradientMain=Q_gradient;
    if (gradientMain<-Q_gradient)gradientMain=-Q_gradient;

    if (distance>(100-Q_gradient))distance=100-Q_gradient;
    if(distance<-(100-Q_gradient))distance=-(100-Q_gradient);

    double possibility=distance+gradientMain+humanObstacle*50;

    //Log.d("gradientMain",main+ "  "+ gradientMain+"   "+distance+"   "+humanObstacle*10+"   "+possibility);

    return possibility;
  }

  //PossibilityA1
  public double PossibilityA1(){

    gradientA1=-(this.A1-A1Storage[Window-1])*validA1*7*Q_gradient/100;
    double distance=(CalA1-this.A1)*10;

    if (distance>(100-Q_gradient))distance=100-Q_gradient;
    if(distance<-(100-Q_gradient))distance=-(100-Q_gradient);

    if (gradientA1>Q_gradient) gradientA1=Q_gradient;
    if (gradientA1<-Q_gradient)gradientA1=-Q_gradient;


    double possibility=distance+gradientA1+humanObstacle*50;
    //if (possibility>1) possibility=1;
    
    Log.d("gradientA1",this.A1+"   "+gradientA1+"   "+distance+"   "+humanObstacle*10+" "+possibility);
    if (possibility>100) possibility=100;
    return possibility;
  }
//PossibilityA2
  public double PossibilityA2(){

    gradientA2=-(this.A2-A2Storage[Window-1])*validA2*7*Q_gradient/100;

    double distance=(CalA2-this.A2)*10;
    //if (possibility>1) possibility=1;

    if (distance>(100-Q_gradient))distance=100-Q_gradient;
    if(distance<-(100-Q_gradient))distance=-(100-Q_gradient);

    if (gradientA2>Q_gradient) gradientA2=Q_gradient;
    if (gradientA2<-Q_gradient)gradientA2=-Q_gradient;

    double possibility=distance+gradientA2+humanObstacle*50;

    Log.d("gradientA2",gradientA2+"   "+distance+"   "+possibility);

    return possibility;
  }

}
