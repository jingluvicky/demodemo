package com.example.ringo.uaes;

/**
 * Created by ringo on 2018/6/12.
 */

public interface HandleNotify {

    void onVehicleKeyReceived();
    void onVehicleKeyCanceled();
}
