package com.example.ringo.uaes;

import android.util.Log;

public class KalmanFilter {
  static double A=1;
  static double Q=0.01;
  static double H=1;
  static double R=10^2;
  static double B=0;
  static double U=0;
  static double x=0;
  static double P;
  static double K;

  public static double FilteredRSSI(double newRSSIValue)

  {
    double z=newRSSIValue;
    if (0==x ){
      x=z;
      P=R;
    }
    else{
      x=x+B*U;
      P=P+Q;
      K=P/(P+R);
      x=x+K*(z-x);
      P=P-K*P;
    }

    Log.d("mainmain",z+"  "+x);
    return x;
  }

}
