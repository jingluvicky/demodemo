package com.example.ringo.uaes;

import android.util.Log;

public class LockStateStrategy {
  static String LockStateStorage="0";
  static final Integer Window=40;
  static Integer curWindow=0;
  static double[] mainStorage=new double[Window];
  static double[] A1Storage=new double[Window];
  static double[] A2Storage=new double[Window];
  static double main;
  static double A1;
  static double A2;
  static boolean validMain, validA1, validA2;
  static Integer Q_gradient=20;
  static float light=0;
  static double humanObstacle=0;
  static double gradientMain,gradientA1,gradientA2;
  LockStateStrategy(){
    for (int i=0;i<Window;i++){
      mainStorage[i]=0;
      A1Storage[i]=0;
      A2Storage[i]=0;
    }
  }
  public void RSSIStorage(double main,double A1,double A2){

    for (int i=Window-1;i>0;i--){
      mainStorage[i]=mainStorage[i-1];
      A1Storage[i]=A1Storage[i-1];
      A2Storage[i]=A2Storage[i-1];
    }
    mainStorage[0]=main;
    A1Storage[0]=A1;
    A2Storage[0]=A2;
  }


  public String LockState(double main, double A1, double A2, boolean validMain, boolean validA1, boolean validA2, float light, float []gravity, float proximity){
    double gradient=main-this.main+A1-this.A1+A2-this.A2;


    this.main=main;
    this.A1=A1;
    this.A2=A2;
    this.validMain=validMain;
    this.validA1=validA1;
    this.validA2=validA2;
    this.light=light;
    RSSIStorage(main,A1,A2);
    double possiMain=PossibilityMain();
    double possiA1=PossibilityA1();
    double possiA2=PossibilityA2();


    //strategy
    Log.d("possi",possiMain+possiA1+possiA2+"  ");
    Log.d("light",light+"  ");
   //bound define
    ;
    float Upperbound=80;
    float Lowerbound=-70;

    //if (light>2){inPocket=0;}
    double possi=possiA1+possiA2;
    //double gradient=gradientA1+gradientMain+gradientA2;
   if (light==0 &&proximity<2&&Math.abs(gravity[1])>8 &&gradient>0.7){
      humanObstacle=1;
    }
    if (gradient <-1 && proximity>2&&humanObstacle>0){
      humanObstacle=humanObstacle-0.05;
    }
    if ( proximity>2 && humanObstacle>0){
      humanObstacle=humanObstacle-0.05;
    }
    //Log.d("gradientsum",gradient+"  ");
      Log.d("obstacle",humanObstacle+"  ");

    if (main<55||
        possiA1+possiA2>Upperbound
        ||possiA2>50
        ||possiA1>50){

      LockStateStorage="2";
      return "2";
    }
    if (possiMain+possiA1+possiA2<Lowerbound){
    //if (PossibilityA2()<-50){
      LockStateStorage="1";
      return "1";
    }

    return LockStateStorage;
  }
//PossibilityMain
  public double PossibilityMain(){
    Integer validMain_int=0;
    if (validMain) validMain_int=1;
    gradientMain=-(this.main-mainStorage[Window-1])*validMain_int*7*Q_gradient/100;
    double distance=(72-this.main)*10;

    if (gradientMain>Q_gradient) gradientMain=Q_gradient;
    if (gradientMain<-Q_gradient)gradientMain=-Q_gradient;

    if (distance>(100-Q_gradient))distance=100-Q_gradient;
    if(distance<-(100-Q_gradient))distance=-(100-Q_gradient);

    double possibility=distance+gradientMain+humanObstacle*50;

    Log.d("gradientMain",main+ "  "+ gradientMain+"   "+distance+"   "+humanObstacle*10+"   "+possibility);

    return possibility;
  }

  //PossibilityA1
  public double PossibilityA1(){
    Integer validA1_int=0;
    if (validA1) validA1_int=1;
    gradientA1=-(this.A1-A1Storage[Window-1])*validA1_int*7*Q_gradient/100;
    double distance=(60-this.A1)*10;

    if (distance>(100-Q_gradient))distance=100-Q_gradient;
    if(distance<-(100-Q_gradient))distance=-(100-Q_gradient);

    if (gradientA1>Q_gradient) gradientA1=Q_gradient;
    if (gradientA1<-Q_gradient)gradientA1=-Q_gradient;


    double possibility=distance+gradientA1+humanObstacle*50;
    //if (possibility>1) possibility=1;
    
    Log.d("gradientA1",this.A1+"   "+gradientA1+"   "+distance+"   "+humanObstacle*10+" "+possibility);
    if (possibility>100) possibility=100;
    return possibility;
  }
//PossibilityA2
  public double PossibilityA2(){
    Integer validA2_int=0;
    if (validA2) validA2_int=1;
    gradientA2=-(this.A2-A2Storage[Window-1])*validA2_int*7*Q_gradient/100;

    double distance=(65-this.A2)*10;
    //if (possibility>1) possibility=1;

    if (distance>(100-Q_gradient))distance=100-Q_gradient;
    if(distance<-(100-Q_gradient))distance=-(100-Q_gradient);

    if (gradientA2>Q_gradient) gradientA2=Q_gradient;
    if (gradientA2<-Q_gradient)gradientA2=-Q_gradient;

    double possibility=distance+gradientA2+humanObstacle*50;

    Log.d("gradientA2",gradientA2+"   "+distance+"   "+possibility);

    return possibility;
  }
}
