package com.example.ringo.uaes;

/**
 * Created by ringo on 2017/6/25.
 */

import android.app.ListFragment;
import android.app.Fragment;
import android.app.FragmentManager;
import android.bluetooth.BluetoothManager;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.view.View.OnClickListener;
import android.widget.TextView;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.Toast;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.annotation.SuppressLint;
import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.content.Context;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.util.Log;
import java.util.ArrayList;
import android.Manifest;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.app.Dialog;
import java.util.UUID;
import java.util.Map;
import java.util.HashMap;


//This is the Ble tab, used to scan and find BLE devices during developing period
public class MainTabScanFragment extends ListFragment  implements OnClickListener,HandleNotify {
    private static final String TAG = "MainTabScanFragment";

    private static Switch scanButton;
    private TextView scanTitle;
   // public startConnectCB MystartConnectCB;
    public MainTabConnectInfoFragment subFragment;
    //BLE Added
    // BlueTooth Related
    // private LeDeviceListAdapter mLeDeviceListAdapter;
    private static BluetoothAdapter mBluetoothAdapter; //Use to control the bluetooth of current device
    private static final int PERMISSION_REQUEST_COARSE_LOCATION = 1;
    public static boolean mScanning;
    private static Handler mHandler;
    private static Handler periodicHandler; //test periodically searching

    public static BluetoothManager bluetoothManager;
    private boolean bEnableScan=true;

    private static Runnable runnable;
    private LeDeviceListAdapter mLeDeviceListAdapter;
    private BluetoothAdapter.LeScanCallback mLeScanCallback = new BluetoothAdapter.LeScanCallback() {

        @Override

        public void onLeScan(final BluetoothDevice device, int rssi, byte[] scanRecord) {
           // TextView frag_bletext=(TextView) getActivity().findViewById(R.id.ble_text);
          //  frag_bletext.append(device.getName()+scanRecord.toString());
            //Toast.makeText(getActivity(), "Find Device"+device.getName(), Toast.LENGTH_SHORT).show();
            mLeDeviceListAdapter.addDevice(device,rssi);
            mLeDeviceListAdapter.notifyDataSetChanged();

            Log.d(TAG, "zyl onLeScan:ble name = " + device.getName());
            if ("SMART PEPS DEMO".equals(device.getName())){
                if(subFragment.mConnected==false){
                    subFragment.setTargetDeviceInfo(device.getName(),device.getAddress(),bluetoothManager);
                }
            }

        }

    };


    public void onAttach(Activity activity) {
        super.onAttach(activity);
       /* try {
            MystartConnectCB = ( startConnectCB) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString() + " must implementOnArticleSelectedListener");
        }*/
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        View view = inflater.inflate(R.layout.fragment_ble, container, false);
        return view;
    }


    public void onActivityCreated(Bundle savedInstanceState){

        subFragment =  new MainTabConnectInfoFragment();
        getChildFragmentManager().beginTransaction().add(R.id.subfragment_container, subFragment)
                .show(subFragment).commit();
        initBLEdevice();
        scanTitle=(TextView) getActivity().findViewById(R.id.txt_scan);
        //scanTitle.setTextColor(100);
        scanButton=(Switch)getActivity().findViewById(R.id.scanswitch); //initialize the scanswitch
        scanButton.setTextOff("OFF");
        scanButton.setTextOn("ON");

        scanButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
            @Override
            public void onCheckedChanged(CompoundButton button,boolean isChecked){

       /* BluetoothDevice Device_A= mBluetoothAdapter.getRemoteDevice("00:11:22:33:AA:BB");
        BluetoothDevice Device_B= mBluetoothAdapter.getRemoteDevice("00:11:22:33:AA:CC");
            mLeDeviceListAdapter.addDevice(Device_A,92);
            mLeDeviceListAdapter.addDevice(Device_B,93);
            mLeDeviceListAdapter.notifyDataSetChanged();*/
                if(isChecked) {
                    //Toast.makeText(getActivity(),"Start Scanning",Toast.LENGTH_SHORT).show();

                    //  mBluetoothAdapter.startLeScan(mLeScanCallback);
                    //  mLeDeviceListAdapter = new LeDeviceListAdapter();
                    //getActivity().setListAdapter(mLeDeviceListAdapter);
                   // if (subFragment.connectedBefore)
                    //{  initBLEdevice();}
                    if(bEnableScan) {

                        scanLeDevice(true);
                        //test periodically searching
                        periodicHandler.postDelayed(runnable, 30000);
                    }


                }else{
                    Toast.makeText(getActivity(),"Stop Scanning",Toast.LENGTH_SHORT).show();
                    scanLeDevice(false);
                    periodicHandler.removeCallbacks(runnable);
                    mLeDeviceListAdapter.clear();
                    mLeDeviceListAdapter.notifyDataSetChanged();
                    if(subFragment.mConnected){
                    subFragment.stopConnecttion();}

                    //mBluetoothAdapter.stopLeScan(mLeScanCallback);
                }


            }

        });


        super.onActivityCreated(savedInstanceState);
    }

    public void onClick(View view){




    }



    public void restartScanTab(){

        if(scanButton.isChecked()){
        //scanLeDevice(false);
        if(subFragment.mConnected==true)
        {subFragment.stopConnecttion();}
        scanButton.setChecked(false);
        periodicHandler.removeCallbacks(runnable);
        mLeDeviceListAdapter.clear();
            mLeDeviceListAdapter.notifyDataSetChanged();}


    }
    /*ListFragment 自带有一个ListView
    * Funtion Added By ZYL on 2017/6/18
    * When user click the device list automatically try to connect it
    * When success show the service found
    * */
    public void onListItemClick(ListView parent, View v,int position, long id) {
        //  Log.d(TAG, "onListItemClick");
        Toast.makeText(getActivity(), "Start connectting  device" + position,
                Toast.LENGTH_SHORT).show();

        //scanLeDevice(false);
        //periodicHandler.removeCallbacks(runnable);
       // mBluetoothAdapter.disable();

         if(subFragment.mConnected==false){
           subFragment.setTargetDeviceInfo(mLeDeviceListAdapter.getDevice(position).getName(),
                   mLeDeviceListAdapter.getDevice(position).getAddress(),bluetoothManager);}
                   //(BluetoothManager) getActivity().getApplicationContext().getSystemService(Context.BLUETOOTH_SERVICE));

       /*


        Toast.makeText(getActivity(), "Address Is:" +mLeDeviceListAdapter.getDevice(position).getAddress(),
                Toast.LENGTH_SHORT).show();
        if(mBluetoothLeService==null)
            Toast.makeText(getActivity(), "mBluetoothLeService Is NULL",
                    Toast.LENGTH_SHORT).show();
        if(!mBluetoothLeService.initialize())
        { Toast.makeText(getActivity(), "Initialize Fail",
                Toast.LENGTH_SHORT).show(); }else {
            if (mBluetoothLeService.connect(mLeDeviceListAdapter.getDevice(position).getAddress())) {
                Toast.makeText(getActivity(), "Connected Succeed",
                        Toast.LENGTH_SHORT).show();

            } else {

                Toast.makeText(getActivity(), "Connected Fail",
                        Toast.LENGTH_SHORT).show();

            }
        } */

    }
    //
    private static final int REQUEST_ENABLE_BT = 1;
    // 10秒后停止查找搜索.
    private static final long SCAN_PERIOD = 29900;
    public  SimpleThread scanthread = new SimpleThread();

    @Override
    public void onVehicleKeyReceived() {
        Log.d(TAG, "onVehicleKeyReceived: ***************************");
        bEnableScan=true;
    }

    @Override
    public void onVehicleKeyCanceled() {

        bEnableScan=false;
        if(mScanning==true){
        restartScanTab();}

    }

    public class SimpleThread extends Thread {
        @Override
        public void run() {
            if(mScanning){
                mBluetoothAdapter.startLeScan(mLeScanCallback);
            }else{
                mBluetoothAdapter.stopLeScan(mLeScanCallback);
            }
        }
    }

    private void initBLEdevice(){

      bluetoothManager = (BluetoothManager)getActivity().getApplicationContext().getSystemService(Context.BLUETOOTH_SERVICE);
        mBluetoothAdapter = bluetoothManager.getAdapter();
        //mBluetoothLeService=new BluetoothLeService();
        // mBluetoothLeService.initialize();
        mHandler = new Handler();
        periodicHandler=new Handler();
        runnable  = new Runnable(){
            @Override
            public void run() {
                scanLeDevice(true);
                Log.d(TAG, "run: zylzz start scan");
                periodicHandler.postDelayed(this, 30000);// 50是延时时长
            }
        };


        //test periodically searching
        if (!mBluetoothAdapter.isEnabled()) {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
            //scanthread.start();
            Log.d("StartBleSearch","not Enabled");
        }else{
            Log.v("StartBleSearch","BLE Is Enabled");;
        }
        mLeDeviceListAdapter = new LeDeviceListAdapter();
        setListAdapter(mLeDeviceListAdapter);
    }

    private void StartBleSearch(){

        if (!mBluetoothAdapter.isEnabled()) {
            if (!mBluetoothAdapter.isEnabled()) {
                Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
                //scanthread.start();
                Log.d("StartBleSearch","not Enabled");
            }
        }else{

            // scanthread.start();
            Log.d("StartBleSearch","Enabled");

        }
        //


    }

    public void StopBleSearch(){

        //scanthread.stop();



    }

    public void onPause() {
        super.onPause();
        // scanthread.stop();

    }
    private class LeDeviceListAdapter extends BaseAdapter {
        private ArrayList<BluetoothDevice> mLeDevices;
        private Map<BluetoothDevice,String> signalstrength;
        private LayoutInflater mInflator;

        private String temp1="ASSIT PEPS NODE ONE";
        private String temp2="ASSIT PEPS NODE TWO";
        private String temp3="ASSIT PEPS NODE THREE";
        private String temp4="ASSIT PEPS NODE FOUR";
        private String temp5="ASSIT PEPS NODE FIVE";
        private String temp6="ASSIT PEPS NODE SIX";
        private String temp7="ASSIT PEPS NODE SEVEN";
        private String temp8="ASSIT PEPS NODE EIGHT";
        private String temp9="ASSIT PEPS NODE NINE";


        public LeDeviceListAdapter() {
            super();
            mLeDevices = new ArrayList<BluetoothDevice>();
            mInflator = getActivity().getLayoutInflater();
            signalstrength=new HashMap<BluetoothDevice,String>();
        }

        public void addDevice(BluetoothDevice device,int RSSI) {
            if(!mLeDevices.contains(device)) {
                mLeDevices.add(device);

            }
            String temp_A=new String();

            temp_A=device.getName();


            if(temp_A!=null&&temp_A.length()>0 ) {

                temp_A=temp_A.trim();

                if (temp_A.equals(temp1)) {
                    subFragment.setAssistRSSI_1(RSSI);
                    //ASSIST 1
                }
                if (temp_A.equals(temp2)) {
                    subFragment.setAssist_RSSI2(RSSI);
                    //ASSIST 2
                }

                if (temp_A.equals(temp3)) {
                    subFragment.setAssistRSSI_3(RSSI);
                    //ASSIST 3
                }

                if (temp_A.equals(temp4)) {
                    subFragment.setAssistRSSI_4(RSSI);
                    //ASSIST 4
                }
                if (temp_A.equals(temp5)) {
                    subFragment.setAssistRSSI_5(RSSI);
                    //ASSIST5
                }
                if (temp_A.equals(temp6)) {
                    subFragment.setAssistRSSI_6(RSSI);
                    //ASSIST 6
                }
                if (temp_A.equals(temp7)) {
                    subFragment.setAssistRSSI_7(RSSI);
                    //ASSIST 7
                }
                if (temp_A.equals(temp8)) {
                    subFragment.setAssistRSSI_8(RSSI);
                    //ASSIST 8
                }
                if (temp_A.equals(temp9)) {
                    subFragment.setAssistRSSI_9(RSSI);
                    //ASSIST 9
                }

            }
            signalstrength.put(device,String.valueOf(RSSI));
        }

        public BluetoothDevice getDevice(int position) {
            return mLeDevices.get(position);
        }

        public void clear() {
            mLeDevices.clear();
            signalstrength.clear();
        }

        @Override
        public int getCount() {
            return mLeDevices.size();
        }

        @Override
        public Object getItem(int i) {
            return mLeDevices.get(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            ViewHolder viewHolder;
            // General ListView optimization code.
            if (view == null) {
                viewHolder = new ViewHolder();
                view = mInflator.inflate(R.layout.ble_list, null);

                viewHolder.deviceAddress = (TextView) view.findViewById(R.id.device_address);
                viewHolder.deviceName = (TextView) view.findViewById(R.id.device_name);
                view.setTag(viewHolder);

            } else {
                viewHolder = (ViewHolder) view.getTag();
            }

            BluetoothDevice device = mLeDevices.get(i);
            final String deviceName = device.getName();
            if (deviceName != null && deviceName.length() > 0)
                viewHolder.deviceName.setText(deviceName);
            else
                viewHolder.deviceName.setText(R.string.unknown_device);
            viewHolder.deviceAddress.setText(device.getAddress()+"       "+signalstrength.get(device)+"dB");

            return view;
        }
    }

    private void scanLeDevice(final boolean enable) {
        Log.d("ScanDevice","1");
        if (enable) {
//             Stops scanning after a pre-defined scan period.
            mHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    mScanning = false;
                    Log.d(TAG, "scanLeDevice: zylzz stop scan2");
                    mBluetoothAdapter.stopLeScan(mLeScanCallback);
                    //invalidateOptionsMenu();
                }
            }, SCAN_PERIOD);

            mScanning = true;
            //Toast.makeText(getActivity(),"Try Start Scanning",Toast.LENGTH_SHORT).show();
            if(mBluetoothAdapter.startLeScan(mLeScanCallback))
            {
                Toast.makeText(getActivity(),"Start Scanning Successfully",Toast.LENGTH_SHORT).show();
            }

        } else {
            mScanning = false;
            Log.d(TAG, "scanLeDevice: zyl stop scan1");

            if (bluetoothManager==null){
                bluetoothManager = (BluetoothManager)getActivity().getApplicationContext().getSystemService(Context.BLUETOOTH_SERVICE);
            }
           if (mBluetoothAdapter==null){
               mBluetoothAdapter = bluetoothManager.getAdapter();
           }
            Log.d(TAG, "scanLeDevice: zyl bluetoothManager==null?" + (bluetoothManager==null));
            Log.d(TAG, "scanLeDevice: zyl mBluetoothAdapter==null?" + (mBluetoothAdapter==null));
            mBluetoothAdapter.stopLeScan(mLeScanCallback);
        }
        // invalidateOptionsMenu();
    }

    public void stopBleConnect(){
        Log.d(TAG, "stopBleConnect: zyl");
        scanButton.setChecked(false);
//        scanLeDevice(false);
//        periodicHandler.removeCallbacks(runnable);
//        mLeDeviceListAdapter.clear();
//        mLeDeviceListAdapter.notifyDataSetChanged();
//        if(subFragment.mConnected){
//            subFragment.stopConnecttion();}
    }

    public void startBleConnect(){
        Log.d(TAG, "startBleConnect: zyl");
        scanButton.setChecked(true);
//        scanLeDevice(true);
//        //test periodically searching
//        periodicHandler.postDelayed(runnable, 30000);
    }

/*
    private BluetoothAdapter.LeScanCallback mLeScanCallback = new BluetoothAdapter.LeScanCallback() {

        @Override
        public void onLeScan(final BluetoothDevice device, int rssi, byte[] scanRecord) {
            //Todo find devices
            /*TextView frag_bletext=(TextView) getActivity().findViewById(R.id.ble_text);
            frag_bletext.append(device.getName()+scanRecord.toString());
            Toast.makeText(getActivity(), "Find Device"+device.getName(), Toast.LENGTH_SHORT).show();*/
            /*getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    //mLeDeviceListAdapter.addDevice(device);
                    //mLeDeviceListAdapter.notifyDataSetChanged();
                    TextView frag_bletext=(TextView) getActivity().findViewById(R.id.ble_text);
                    frag_bletext.append(device.getName()+device.getAddress());
                    Toast.makeText(getActivity(), "Find Device"+device.getName(), Toast.LENGTH_SHORT).show();
                }
            });
        }
    };*/

    static class ViewHolder {
        TextView deviceName;
        TextView deviceAddress;
    }

/*

   public void startConnectCB(){

       //public void showConnecttedState(String deviceName, String deviceAddress,BluetoothManager  workbluetoothManager);
      subFragment.setTargetDeviceInfo( deviceName,  deviceAddress, workbluetoothManager);
   }
*/























}//End of Fragment Class
