package com.example.ringo.uaes;

public class KalmanFilter_A6 {
    static double A=1;
    static double Q=0.03;
    static double H=1;
    static double R=10^2;
    static double B=0;
    static double U=0;
    static double x=0;
    static double P;
    static double K;
    static double z;

    // public static DataService dataService=new DataService();


  /*public static double accel(){
    double accele=0;
    DataService dataService=new DataService();
   // if ((dataService.accelerometerValues)!=null){
   /// accele=dataService.accelerometerValues[0]*dataService.accelerometerValues[0]+dataService.accelerometerValues[1]*dataService.accelerometerValues[1];
    //Log.d("acce",accele+" " );}
    return accele;
  }*/

    public static double FilteredRSSI(double newRSSIValue,boolean valid)

    {

        z=newRSSIValue;
        if (0==x ){
            x=newRSSIValue;
            P=R;
        }
        if (valid) z=newRSSIValue;else z=x;
        if(0!=x){
            x=x+B*U;
            P=P+Q;
            K=P/(P+R);
            x=x+K*(z-x);
            P=P-K*P;
        }
        return x;
    }

}
