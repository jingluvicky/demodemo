package com.example.ringo.uaes;

public class KalmanFilter_A1 {
    static double A=1;
    static double Q=0.06;
    static double H=1;
    static double R=5^2;
    static double B=0;
    static double U=0;
    static double x=0;
    static double P;
    static double K;
    static double z;

    public static double FilteredRSSI(double newRSSIValue,boolean valid)

    {
        z=newRSSIValue;
        if (0==x ){
            x=newRSSIValue;
            P=R;
        }
        if (valid) z=newRSSIValue;else z=x;
        if(0!=x){
            x=x+B*U;
            P=P+Q;
            K=P/(P+R);
            x=x+K*(z-x);
            P=P-K*P;
        }
        return x;
    }

}

